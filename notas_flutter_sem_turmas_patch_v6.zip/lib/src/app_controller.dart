
import 'dart:async';
import 'dart:math';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';

import 'models.dart';
import 'services.dart'; // BackupEntry defined here

class MediaCue {
  const MediaCue({
    required this.assetPath,
    required this.isVideo,
    required this.duration,
  });
  final String assetPath;
  final bool isVideo;
  final Duration duration;
}

// ──────────────────────────────────────────────────────────────
// MediaService
// ──────────────────────────────────────────────────────────────
class MediaService {
  final AudioPlayer _sfxPlayer = AudioPlayer();
  final AudioPlayer _eventPlayer = AudioPlayer();
  bool muted = false;

  Completer<void>? _eventPlaybackCompleter;
  StreamSubscription<void>? _eventCompleteSubscription;

  Future<void> playAsset(String asset,
      {double volume = 1.0, bool isEvent = false}) async {
    if (muted) return;
    final player = isEvent ? _eventPlayer : _sfxPlayer;
    await player.stop();
    await player.setReleaseMode(ReleaseMode.stop);
    await player.setVolume(volume.clamp(0.0, 1.0));
    await player.play(AssetSource(asset));
  }

  Future<void> playEventAssetAndWait(
    String asset, {
    double volume = 1.0,
    Duration fallbackDuration = const Duration(seconds: 30),
  }) async {
    if (muted) return;

    await stopEvents();
    _eventPlaybackCompleter = Completer<void>();
    await _eventCompleteSubscription?.cancel();
    _eventCompleteSubscription = _eventPlayer.onPlayerComplete.listen((_) {
      final completer = _eventPlaybackCompleter;
      if (completer != null && !completer.isCompleted) {
        completer.complete();
      }
    });

    await _eventPlayer.setReleaseMode(ReleaseMode.stop);
    await _eventPlayer.setVolume(volume.clamp(0.0, 1.0));
    await _eventPlayer.play(AssetSource(asset));

    final completer = _eventPlaybackCompleter;
    if (completer == null) return;

    try {
      await completer.future.timeout(fallbackDuration, onTimeout: () {});
    } finally {
      await _eventCompleteSubscription?.cancel();
      _eventCompleteSubscription = null;
    }
  }

  Future<void> stopEvents() async {
    await _eventPlayer.stop();
    final completer = _eventPlaybackCompleter;
    if (completer != null && !completer.isCompleted) {
      completer.complete();
    }
  }

  Future<void> setMuted(bool value) async {
    muted = value;
    if (muted) {
      await _sfxPlayer.stop();
      await stopEvents();
    }
  }

  Future<void> dispose() async {
    await _eventCompleteSubscription?.cancel();
    await _sfxPlayer.dispose();
    await _eventPlayer.dispose();
  }
}

// ──────────────────────────────────────────────────────────────
// AppController
// ──────────────────────────────────────────────────────────────
class AppController extends ChangeNotifier {
  AppController({
    required this.databaseService,
    required this.fileService,
    required this.mediaService,
  });

  final LocalDatabaseService databaseService;
  final AppFileService fileService;
  final MediaService mediaService;

  AppStateData? state;
  bool loading = true;
  String saveStatus = 'Carregando...';
  String infoMessage = '';
  String? lastError;
  String searchText = '';
  bool rouletteSpinning = false;
  double rouletteRotation = 0;

  // Overlay
  MediaCue? activeOverlayMedia;
  List<String> activeOverlayEmojis = const [];
  String? overlayTitle;
  String? overlaySubtitle;
  bool overlayShowsRouletteButtons = false;
  String? activeOverlayKind;
  int _overlaySession = 0;
  VoidCallback? _onOverlayDismiss;

  // Roleta: estado pós-revelação
  bool correctCelebrated = false;
  bool bonusApplied = false;

  // Backups
  List<BackupEntry> backupList = [];

  final Random _random = Random();
  Future<void> _saveChain = Future<void>.value();

  final List<MediaCue> _successPool = [
    const MediaCue(assetPath: 'assets/images/h1.gif',       isVideo: false, duration: Duration(seconds: 3)),
    const MediaCue(assetPath: 'assets/images/h2.gif',       isVideo: false, duration: Duration(seconds: 3)),
    const MediaCue(assetPath: 'assets/images/dansh.gif',    isVideo: false, duration: Duration(seconds: 4)),
    const MediaCue(assetPath: 'assets/videos/vandamme.mp4', isVideo: true,  duration: Duration(seconds: 4)),
  ];

  final List<MediaCue> _failurePool = [
    const MediaCue(assetPath: 'assets/images/bye.gif',               isVideo: false, duration: Duration(seconds: 3)),
    const MediaCue(assetPath: 'assets/images/crying_the_office.gif', isVideo: false, duration: Duration(seconds: 4)),
    const MediaCue(assetPath: 'assets/images/sad_crying.gif',        isVideo: false, duration: Duration(seconds: 3)),
  ];

  // ── Init ──────────────────────────────────────────────
  Future<void> init() async {
    loading = true;
    notifyListeners();
    await databaseService.init();
    state = await databaseService.loadState();
    mediaService.muted = state?.muted ?? false;
    backupList = await databaseService.getBackupList();
    loading = false;
    saveStatus = 'Dados carregados localmente';
    notifyListeners();
  }

  bool get ready => !loading && state != null;
  AppStateData get currentState => state!;
  bool get hasClasses => ready && currentState.classes.isNotEmpty;
  SchoolClass? get activeClassOrNull {
    if (!ready || currentState.classes.isEmpty) return null;
    final c = currentState.classByKey(currentState.activeClassKey);
    if (c != null) return c;
    currentState.normalize();
    return currentState.classByKey(currentState.activeClassKey);
  }
  SchoolClass get activeClass => activeClassOrNull ?? (throw StateError('Nenhuma turma ativa.'));
  String currentTabFor(String classKey) => currentState.subTabByClass[classKey] ?? 'activities';

  // ── Config ────────────────────────────────────────────
  Future<void> setMuted(bool value) async {
    if (!ready) return;
    currentState.muted = value;
    await mediaService.setMuted(value);
    await _save('Preferência de áudio atualizada');
  }

  void setActiveClass(String key) {
    if (!ready) return;
    if (currentState.classByKey(key) == null) return;
    currentState.activeClassKey = key;
    notifyListeners();
    _save('Turma ativa alterada');
  }

  Future<void> addClass(String title) async {
    if (!ready) return;
    final created = currentState.createClass(title: title);
    currentState.activeClassKey = created.key;
    notifyListeners();
    await mediaService.playAsset('audio/confirm.wav', volume: 0.75);
    await _save('Nova turma adicionada');
  }

  Future<void> renameClass(SchoolClass schoolClass, String title) async {
    if (!ready) return;
    currentState.renameClass(schoolClass, title);
    notifyListeners();
    await mediaService.playAsset('audio/confirm.wav', volume: 0.75);
    await _save('Turma renomeada');
  }

  Future<void> removeClass(SchoolClass schoolClass) async {
    if (!ready) return;
    final removedKey = schoolClass.key;
    currentState.removeClassByKey(removedKey);
    if (currentState.activeClassKey == removedKey) {
      currentState.activeClassKey = currentState.classes.isNotEmpty ? currentState.classes.first.key : '';
    }
    notifyListeners();
    await mediaService.playAsset('audio/reset.wav', volume: 0.7);
    await _save('Turma removida');
  }

  void setCurrentTab(String tab) {
    if (!ready) return;
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    currentState.subTabByClass[schoolClass.key] = tab;
    notifyListeners();
    _save('Aba da turma atualizada');
  }

  void updateSearch(String value) {
    searchText = value;
    notifyListeners();
  }

  List<StudentRecord> get filteredStudents {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return const [];
    final norm = normalizeText(searchText);
    final students = [...schoolClass.students];
    if (norm.isEmpty) return students;
    return students
        .where((s) => normalizeText('${s.name} ${s.code} ${s.number} ${s.status}').contains(norm))
        .toList();
  }

  ClassSummary get activeSummary => activeClassOrNull == null ? ClassSummary.empty() : computeClassSummary(activeClass);

  // ── Notas ─────────────────────────────────────────────
  Future<void> setActivityCount(int value) async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    schoolClass.activityCount = value.clamp(1, 10);
    notifyListeners();
    await mediaService.playAsset('audio/tap.wav', volume: 0.55);
    await _save('Quantidade de atividades atualizada');
  }

  Future<void> setExtraCount(int value) async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    schoolClass.extraCount = value.clamp(1, 10);
    notifyListeners();
    await mediaService.playAsset('audio/tap.wav', volume: 0.55);
    await _save('Quantidade de pontos extras atualizada');
  }

  Future<void> setActivityEmoji(StudentRecord student, int index, double? value) async {
    student.notes[index] = value;
    notifyListeners();
    await mediaService.playAsset('audio/confirm.wav', volume: 0.75);
    await _save('Atividade atualizada');
  }

  Future<void> setAvValue(StudentRecord student, int index, double? value) async {
    student.avs[index] = value == null ? null : round2(value.clamp(0, 10));
    notifyListeners();
    await mediaService.playAsset('audio/confirm.wav', volume: 0.75);
    await _save('AV atualizada');
  }

  Future<void> setExtraValue(StudentRecord student, int index, double? value) async {
    student.extras[index] = value == null ? null : round1(value.clamp(0.5, 5.0));
    notifyListeners();
    await mediaService.playAsset('audio/confirm.wav', volume: 0.75);
    await _save('Ponto extra atualizado');
  }

  Future<void> resetActivities() async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    for (final s in schoolClass.students) s.notes = List<double?>.filled(10, null);
    notifyListeners();
    await mediaService.playAsset('audio/reset.wav', volume: 0.8);
    await _save('Atividades da turma resetadas');
  }

  Future<void> resetAvs() async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    for (final s in schoolClass.students) {
      s.avs = List<double?>.filled(3, null);
      s.extraApplied = List<double>.filled(3, 0);
    }
    notifyListeners();
    await mediaService.playAsset('audio/reset.wav', volume: 0.8);
    await _save('AVs da turma resetadas');
  }

  Future<void> resetExtras() async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    for (final s in schoolClass.students) {
      s.extras = List<double?>.filled(10, null);
      s.extraApplied = List<double>.filled(3, 0);
    }
    notifyListeners();
    await mediaService.playAsset('audio/reset.wav', volume: 0.8);
    await _save('Pontos extras da turma resetados');
  }

  Future<void> exportActivitiesToAvs(Set<int> avIndexes) async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    var changed = 0;
    for (final s in schoolClass.students) {
      final avg = s.activityAverageOrNull(schoolClass.activityCount);
      if (avg == null) continue;
      for (final i in avIndexes) {
        s.avs[i] = round2((round2(avg) + round2(s.extraApplied[i])).clamp(0, 10));
      }
      changed++;
    }
    notifyListeners();
    if (changed > 0) {
      await mediaService.playAsset('audio/export.wav', volume: 0.8);
      await _save('Médias das atividades lançadas nas AVs');
    } else {
      await mediaService.playAsset('audio/error.wav', volume: 0.9);
      infoMessage = 'Nenhum aluno com nota em atividades foi encontrado para lançar nas AVs.';
      notifyListeners();
    }
  }

  Future<int> exportExtrasToAvs(Set<int> avIndexes, {String? studentId}) async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return 0;
    final targets = studentId == null
        ? schoolClass.students
        : schoolClass.students.where((s) => s.id == studentId).toList();
    var changed = 0;
    for (final s in targets) {
      final total = s.extraTotal(schoolClass.extraCount);
      var localChanged = false;
      for (final i in avIndexes) {
        final delta = round2(total - s.extraApplied[i]);
        if (delta.abs() < 0.001) continue;
        s.avs[i] = round2(((s.avs[i] ?? 0.0) + delta).clamp(0, 10));
        s.extraApplied[i] = total;
        localChanged = true;
      }
      if (localChanged) changed++;
    }
    notifyListeners();
    if (changed > 0) {
      await mediaService.playAsset('audio/export.wav', volume: 0.8);
      await _save('Pontos extras somados nas AVs');
    } else {
      await mediaService.playAsset('audio/error.wav', volume: 0.9);
      infoMessage = 'Nenhum bônus novo precisou ser somado nas AVs escolhidas.';
      notifyListeners();
    }
    return changed;
  }

  Future<void> applyRouletteReward({
    required StudentRecord student,
    required int avIndex,
    required double points,
  }) async {
    final current = student.avs[avIndex] ?? 0.0;
    student.avs[avIndex] = round2((current + points).clamp(0, 10));
    bonusApplied = true;
    notifyListeners();
    await mediaService.playAsset('audio/confirm.wav', volume: 0.85);
    await _save('Premiação da roleta aplicada');
  }

  Future<void> addOrUpdateStudent({
    StudentRecord? original,
    required int number,
    required String code,
    required String name,
    required String status,
  }) async {
    if (original == null) {
      final schoolClass = activeClassOrNull;
      if (schoolClass == null) return;
      schoolClass.students.add(StudentRecord(
        id: 'student_${DateTime.now().microsecondsSinceEpoch}_${_random.nextInt(9999)}',
        number: number, code: code, name: name, status: status,
        notes: List<double?>.filled(10, null),
        avs: List<double?>.filled(3, null),
        extras: List<double?>.filled(10, null),
        extraApplied: List<double>.filled(3, 0),
      ));
    } else {
      original.number = number;
      original.code = code;
      original.name = name;
      original.status = status;
    }
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    schoolClass.normalize();
    notifyListeners();
    await mediaService.playAsset('audio/confirm.wav', volume: 0.75);
    await _save(original == null ? 'Aluno adicionado' : 'Aluno editado');
  }

  Future<void> removeStudent(StudentRecord student) async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    schoolClass.students.removeWhere((s) => s.id == student.id);
    schoolClass.roulettePickedIds.remove(student.id);
    if (schoolClass.rouletteCurrentId == student.id) schoolClass.rouletteCurrentId = null;
    if (schoolClass.rouletteLastRevealId == student.id) schoolClass.rouletteLastRevealId = null;
    schoolClass.normalize();
    notifyListeners();
    await mediaService.playAsset('audio/reset.wav', volume: 0.7);
    await _save('Aluno removido');
  }

  Future<void> clearAllData() async {
    state = await LocalDatabaseService.loadSeedState();
    state!.normalize();
    await databaseService.saveState(state!);
    searchText = '';
    saveStatus = 'Todos os dados foram reinicializados.';
    notifyListeners();
    await mediaService.playAsset('audio/reset.wav', volume: 0.9);
  }

  Future<void> importFromFile() async {
    try {
      final picked = await fileService.pickImportFile();
      if (picked == null) return;
      state = picked.extension == 'json'
          ? await fileService.importJson(picked.bytes, currentState)
          : await fileService.importExcel(picked.bytes, currentState);
      state!.normalize();
      await databaseService.saveState(state!);
      infoMessage = 'Importação concluída: ${picked.name}';
      saveStatus = 'Dados importados e salvos localmente';
      notifyListeners();
      await mediaService.playAsset('audio/export.wav', volume: 0.8);
    } catch (error) {
      lastError = 'Falha ao importar arquivo: $error';
      notifyListeners();
      await mediaService.playAsset('audio/error.wav', volume: 0.95);
    }
  }

  Future<void> exportJson() async {
    final bytes = fileService.buildJson(currentState);
    await fileService.saveBytes(
      bytes: bytes, suggestedName: 'notas_flutter_backup.json',
      mimeType: 'application/json', shareText: 'Backup JSON do app Notas.',
    );
    await mediaService.playAsset('audio/export.wav', volume: 0.8);
  }

  Future<void> exportExcel() async {
    if (!hasClasses) {
      infoMessage = 'Crie ou importe uma turma antes de exportar para Excel.';
      notifyListeners();
      await mediaService.playAsset('audio/error.wav', volume: 0.95);
      return;
    }
    final bytes = fileService.buildExcel(currentState);
    await fileService.saveBytes(
      bytes: bytes, suggestedName: 'notas_flutter.xlsx',
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      shareText: 'Planilha Excel exportada pelo app Notas.',
    );
    await mediaService.playAsset('audio/export.wav', volume: 0.8);
  }

  // ── Roleta ────────────────────────────────────────────
  Future<StudentRecord?> spinRoulette() async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null || rouletteSpinning || schoolClass.students.isEmpty) return null;
    final available = schoolClass.students
        .where((s) => !schoolClass.roulettePickedIds.contains(s.id))
        .toList();
    if (available.isEmpty) {
      infoMessage = 'Todos os alunos já foram sorteados. Use o botão de reset para recomeçar.';
      notifyListeners();
      await mediaService.playAsset('audio/error.wav', volume: 0.95);
      return null;
    }

    correctCelebrated = false;
    bonusApplied = false;

    final selected = available[_random.nextInt(available.length)];
    final index = schoolClass.students.indexWhere((s) => s.id == selected.id);
    final slice = (pi * 2) / schoolClass.students.length;
    final targetRotation = rouletteRotation + pi * 8 +
        ((schoolClass.students.length - index) * slice) + slice / 2;

    rouletteSpinning = true;
    schoolClass.rouletteCurrentId = null;
    schoolClass.rouletteLastRevealId = null;
    rouletteRotation = targetRotation;
    notifyListeners();

    await mediaService.playAsset('audio/spin.wav', volume: 1.0, isEvent: true);
    await Future<void>.delayed(const Duration(milliseconds: 2800));

    rouletteSpinning = false;
    schoolClass.rouletteCurrentId = selected.id;
    schoolClass.rouletteLastPickedId = selected.id;
    schoolClass.roulettePickedIds.add(selected.id);
    await _save('Roleta executada');
    notifyListeners();
    return selected;
  }

  Future<void> resetRoulette() async {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    schoolClass.roulettePickedIds.clear();
    schoolClass.rouletteCurrentId = null;
    schoolClass.rouletteLastRevealId = null;
    schoolClass.rouletteLastPickedId = null;
    rouletteRotation = 0;
    correctCelebrated = false;
    bonusApplied = false;
    notifyListeners();
    await mediaService.playAsset('audio/reset.wav', volume: 0.85);
    await _save('Roleta resetada');
  }

  /// Toque no número → overlay com GIF e emojis até o áudio acabar
  Future<void> revealCurrentRouletteStudent() async {
    final student = currentRouletteStudent;
    if (student == null) return;
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return;
    schoolClass.rouletteLastRevealId = student.id;
    notifyListeners();
    await _showOverlay(
      title: student.name,
      subtitle: 'Você é o meu escolhido! 🎯',
      media: const MediaCue(
        assetPath: 'assets/images/voce_escolhido.gif',
        isVideo: false,
        duration: Duration(seconds: 6),
      ),
      emojis: const ['🎉', '🥳', '✨', '😄', '🎊', '🙌'],
      audioAsset: 'audio/escolhido.mp3',
      showRouletteButtons: false,
      overlayKind: 'reveal',
    );
    await _save('Aluno sorteado revelado');
  }

  StudentRecord? get currentRouletteStudent {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return null;
    final id = schoolClass.rouletteCurrentId;
    if (id == null) return null;
    try { return schoolClass.students.firstWhere((s) => s.id == id); }
    catch (_) { return null; }
  }

  StudentRecord? get lastRouletteStudent {
    final schoolClass = activeClassOrNull;
    if (schoolClass == null) return null;
    final id = schoolClass.rouletteLastPickedId;
    if (id == null) return null;
    try { return schoolClass.students.firstWhere((s) => s.id == id); }
    catch (_) { return null; }
  }

  int get rouletteSpinCount => activeClassOrNull?.roulettePickedIds.length ?? 0;

  bool get rouletteRevealed {
      final schoolClass = activeClassOrNull;
      return schoolClass != null &&
          schoolClass.rouletteCurrentId != null &&
          schoolClass.rouletteCurrentId == schoolClass.rouletteLastRevealId;
  }

  /// Mantido por compatibilidade com a UI; usa os botões inferiores da roleta.
  Future<void> handleRevealCorrect() async {
    await celebrateCorrect();
  }

  /// Mantido por compatibilidade com a UI; usa os botões inferiores da roleta.
  Future<void> handleRevealWrong() async {
    await celebrateWrong();
  }

  /// Acertou pela barra inferior da roleta.
  Future<void> celebrateCorrect() async {
    dismissOverlay();
    correctCelebrated = true;
    bonusApplied = false;
    notifyListeners();
    await _runCelebration(correct: true);
  }

  /// Errou pela barra inferior da roleta.
  Future<void> celebrateWrong() async {
    dismissOverlay();
    correctCelebrated = false;
    notifyListeners();
    await _runCelebration(correct: false);
  }

  Future<void> _runCelebration({required bool correct}) async {
    if (correct) {
      final cue = _takeNextCue(_successPool);
      await _showOverlay(
        title: 'Acertou! 🎉',
        subtitle: 'Mandou muito bem!',
        media: cue,
        emojis: const ['😎', '👑', '🔥', '🎉', '⭐', '🥳'],
        audioAsset: 'audio/acertou.mp3',
        showRouletteButtons: false,
        overlayKind: 'correct',
      );
    } else {
      final cue = _takeNextCue(_failurePool);
      await _showOverlay(
        title: 'Errou! 😢',
        subtitle: 'Respira e tenta de novo',
        media: cue,
        emojis: const ['😿', '💔', '😢', '🫠', '☁️', '🥺'],
        audioAsset: 'audio/errou.mp3',
        showRouletteButtons: false,
        overlayKind: 'wrong',
      );
    }
  }

  MediaCue _takeNextCue(List<MediaCue> source) {
    if (source.length <= 1) return source.first;
    source.shuffle(_random);
    return source.first;
  }

  // ── Overlay ───────────────────────────────────────────
  Future<void> _showOverlay({
    required String title,
    required String subtitle,
    required MediaCue media,
    required List<String> emojis,
    required String audioAsset,
    bool showRouletteButtons = false,
    String? overlayKind,
    VoidCallback? onDismiss,
  }) async {
    final sessionId = ++_overlaySession;
    _onOverlayDismiss = onDismiss;
    activeOverlayMedia = media;
    activeOverlayEmojis = emojis;
    overlayTitle = title;
    overlaySubtitle = subtitle;
    overlayShowsRouletteButtons = showRouletteButtons;
    activeOverlayKind = overlayKind;
    notifyListeners();

    await mediaService.playEventAssetAndWait(
      audioAsset,
      volume: 1.0,
      fallbackDuration: const Duration(seconds: 30),
    );

    if (sessionId == _overlaySession && activeOverlayMedia != null) {
      dismissOverlay();
    }
  }

  void stopOverlayPlayback() {
    dismissOverlay();
  }

  /// Fecha o overlay — chamado pelo fim do áudio ou manualmente.
  void dismissOverlay() {
    _overlaySession++;
    unawaited(mediaService.stopEvents());
    final cb = _onOverlayDismiss;
    _onOverlayDismiss = null;
    activeOverlayMedia = null;
    activeOverlayEmojis = const [];
    overlayTitle = null;
    overlaySubtitle = null;
    overlayShowsRouletteButtons = false;
    activeOverlayKind = null;
    notifyListeners();
    cb?.call();
  }

  // ── Emojis ────────────────────────────────────────────
  String gradeEmoji(double? v) {
    if (v == null) return '➕';
    if (v < 6)  return '😞';
    if (v < 8)  return '🙌';
    if (v < 10) return '😄';
    return '😎';
  }

  String activityEmoji(double? v) {
    if (v == null) return '➕';
    if (v >= 10) return '😄';
    if (v >= 8)  return '🙂';
    if (v >= 7)  return '😅';
    return '😞';
  }

  String extraEmoji(double? v) => v == null ? '➕' : '🙂';

  List<String> rankingCharactersFor(ClassSummary summary) {
    final malePool   = ['assets/images/mario.png', 'assets/images/toad.png', 'assets/images/bowser.png'];
    final femalePool = ['assets/images/daisy.png', 'assets/images/peach.png', 'assets/images/rosalina.png'];
    final usedM = <String>{};
    final usedF = <String>{};
    final out = <String>[];
    for (var i = 0; i < summary.ranked.length; i++) {
      final e = summary.ranked[i];
      final seed = e.student.id.hashCode.abs() + i * 17;
      if (e.gender == 'female') {
        final opts = femalePool.where((x) => !usedF.contains(x)).toList();
        final pick = (opts.isEmpty ? femalePool : opts)[seed % (opts.isEmpty ? femalePool.length : opts.length)];
        usedF.add(pick); out.add(pick);
      } else {
        final opts = malePool.where((x) => !usedM.contains(x)).toList();
        final pick = (opts.isEmpty ? malePool : opts)[seed % (opts.isEmpty ? malePool.length : opts.length)];
        usedM.add(pick); out.add(pick);
      }
    }
    return out;
  }

  // ── Backup ────────────────────────────────────────────
  Future<void> refreshBackupList() async {
    backupList = await databaseService.getBackupList();
    notifyListeners();
  }

  Future<void> restoreBackup(BackupEntry entry) async {
    try {
      state = await databaseService.restoreBackup(entry.slot);
      state!.normalize();
      await databaseService.saveState(state!);
      saveStatus = 'Backup restaurado: ${entry.label}';
      infoMessage = 'Dados restaurados do backup de ${entry.label}';
      backupList = await databaseService.getBackupList();
      notifyListeners();
      await mediaService.playAsset('audio/export.wav', volume: 0.8);
    } catch (error) {
      lastError = 'Falha ao restaurar backup: $error';
      notifyListeners();
      await mediaService.playAsset('audio/error.wav', volume: 0.95);
    }
  }

  // ── Salvar ────────────────────────────────────────────
  Future<void> _save(String reason) async {
    if (!ready) return;
    currentState.updatedAt = DateTime.now();
    currentState.normalize();
    _saveChain = _saveChain.then((_) async {
      await databaseService.saveBackup(currentState);
      await databaseService.saveState(currentState);
      backupList = await databaseService.getBackupList();
      saveStatus = '$reason • salvo às ${_timeStamp(currentState.updatedAt!)}';
      notifyListeners();
    }).catchError((error) {
      lastError = 'Falha ao salvar: $error';
      notifyListeners();
    });
    return _saveChain;
  }

  String _timeStamp(DateTime v) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(v.hour)}:${two(v.minute)}:${two(v.second)}';
  }

  @override
  void dispose() {
    mediaService.dispose();
    super.dispose();
  }
}
