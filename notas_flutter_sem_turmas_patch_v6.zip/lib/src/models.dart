import 'dart:convert';
import 'dart:math';

class AppStateData {
  AppStateData({
    required this.appVersion,
    required this.activeClassKey,
    required this.updatedAt,
    required this.muted,
    required this.classes,
    required this.subTabByClass,
  });

  String appVersion;
  String activeClassKey;
  DateTime? updatedAt;
  bool muted;
  List<SchoolClass> classes;
  Map<String, String> subTabByClass;

  factory AppStateData.fromJson(Map<String, dynamic> json) {
    final classes = (json['classes'] as List? ?? const [])
        .whereType<Map>()
        .map((raw) => SchoolClass.fromJson(Map<String, dynamic>.from(raw)))
        .toList();

    final subTabs = <String, String>{};
    final rawSubTabs = json['subTabByClass'];
    if (rawSubTabs is Map) {
      rawSubTabs.forEach((key, value) {
        subTabs['$key'] = '$value';
      });
    }

    final state = AppStateData(
      appVersion: '${json['appVersion'] ?? '3.0.0'}',
      activeClassKey: '${json['activeClass'] ?? json['activeClassKey'] ?? ''}',
      updatedAt: _tryParseDate(json['updatedAt']),
      muted: json['muted'] == true,
      classes: classes,
      subTabByClass: subTabs,
    );
    state.normalize();
    return state;
  }

  Map<String, dynamic> toJson() {
    return {
      'appVersion': appVersion,
      'activeClass': activeClassKey,
      'updatedAt': updatedAt?.toIso8601String(),
      'muted': muted,
      'classes': classes.map((e) => e.toJson()).toList(),
      'subTabByClass': subTabByClass,
    };
  }

  AppStateData clone() => AppStateData.fromJson(
        jsonDecode(jsonEncode(toJson())) as Map<String, dynamic>,
      );

  void normalize() {
    final usedKeys = <String>{};
    final usedSheets = <String>{};

    for (final schoolClass in classes) {
      schoolClass.normalize();

      final desiredTitle = schoolClass.title.trim().isEmpty
          ? (schoolClass.sheetName.trim().isEmpty ? 'Turma' : schoolClass.sheetName)
          : schoolClass.title.trim();
      schoolClass.title = desiredTitle;

      var keyCandidate = schoolClass.key.trim();
      if (keyCandidate.isEmpty) {
        keyCandidate = buildClassKey(desiredTitle);
      }
      schoolClass.key = _nextUniqueKey(usedKeys, keyCandidate, desiredTitle);
      usedKeys.add(schoolClass.key);

      final desiredSheet = schoolClass.sheetName.trim().isEmpty
          ? desiredTitle
          : schoolClass.sheetName.trim();
      schoolClass.sheetName = _nextUniqueSheetName(usedSheets, desiredSheet);
      usedSheets.add(schoolClass.sheetName);

      subTabByClass.putIfAbsent(schoolClass.key, () => 'activities');
    }

    subTabByClass.removeWhere((key, _) => classes.every((item) => item.key != key));

    if (classes.isEmpty) {
      activeClassKey = '';
      return;
    }

    if (activeClassKey.isEmpty && classes.isNotEmpty) {
      activeClassKey = classes.first.key;
    }
    if (classes.every((item) => item.key != activeClassKey) && classes.isNotEmpty) {
      activeClassKey = classes.first.key;
    }
  }

  SchoolClass? classByKey(String key) {
    for (final schoolClass in classes) {
      if (schoolClass.key == key) return schoolClass;
    }
    return null;
  }

  SchoolClass? findClassForImport({String? key, String? title, String? sheetName}) {
    final normalizedKey = normalizeText(key ?? '');
    final normalizedTitle = normalizeText(title ?? '');
    final normalizedSheet = normalizeText(sheetName ?? '');

    for (final schoolClass in classes) {
      if (normalizedKey.isNotEmpty && normalizeText(schoolClass.key) == normalizedKey) {
        return schoolClass;
      }
      if (normalizedTitle.isNotEmpty && normalizeText(schoolClass.title) == normalizedTitle) {
        return schoolClass;
      }
      if (normalizedSheet.isNotEmpty && normalizeText(schoolClass.sheetName) == normalizedSheet) {
        return schoolClass;
      }
    }
    return null;
  }

  SchoolClass createClass({
    required String title,
    int activityCount = 1,
    int extraCount = 1,
    String? preferredSheetName,
  }) {
    final key = _nextUniqueKey(classes.map((item) => item.key).toSet(), buildClassKey(title), title);
    final sheetName = _nextUniqueSheetName(
      classes.map((item) => item.sheetName).toSet(),
      preferredSheetName ?? title,
    );
    final schoolClass = SchoolClass.empty(
      key: key,
      sheetName: sheetName,
      title: title.trim().isEmpty ? 'Turma' : title.trim(),
      activityCount: activityCount,
      extraCount: extraCount,
    );
    classes.add(schoolClass);
    subTabByClass[schoolClass.key] = 'activities';
    normalize();
    return schoolClass;
  }

  void renameClass(SchoolClass schoolClass, String newTitle) {
    final title = newTitle.trim().isEmpty ? 'Turma' : newTitle.trim();
    schoolClass.title = title;
    schoolClass.sheetName = _nextUniqueSheetName(
      classes.where((item) => item.key != schoolClass.key).map((item) => item.sheetName).toSet(),
      title,
    );
    normalize();
  }

  void removeClassByKey(String key) {
    classes.removeWhere((item) => item.key == key);
    subTabByClass.remove(key);
    normalize();
  }
}

class SchoolClass {
  SchoolClass({
    required this.key,
    required this.sheetName,
    required this.title,
    required this.activityCount,
    required this.extraCount,
    required this.students,
    required this.roulettePickedIds,
    this.rouletteCurrentId,
    this.rouletteLastRevealId,
    this.rouletteLastPickedId,
  });

  factory SchoolClass.empty({
    required String key,
    required String sheetName,
    required String title,
    int activityCount = 1,
    int extraCount = 1,
  }) {
    return SchoolClass(
      key: key,
      sheetName: sheetName,
      title: title,
      activityCount: activityCount,
      extraCount: extraCount,
      students: <StudentRecord>[],
      roulettePickedIds: <String>[],
    );
  }

  String key;
  String sheetName;
  String title;
  int activityCount;
  int extraCount;
  List<StudentRecord> students;
  List<String> roulettePickedIds;
  String? rouletteCurrentId;
  String? rouletteLastRevealId;
  String? rouletteLastPickedId;

  factory SchoolClass.fromJson(Map<String, dynamic> json) {
    return SchoolClass(
      key: '${json['key'] ?? ''}',
      sheetName: '${json['sheetName'] ?? json['title'] ?? ''}',
      title: '${json['title'] ?? json['key'] ?? ''}',
      activityCount: _toInt(json['activityCount'], fallback: 1),
      extraCount: _toInt(json['extraCount'], fallback: 1),
      students: (json['students'] as List? ?? const [])
          .whereType<Map>()
          .map((raw) => StudentRecord.fromJson(Map<String, dynamic>.from(raw)))
          .toList(),
      roulettePickedIds: (json['roulettePickedIds'] as List? ?? const []).map((e) => '$e').toList(),
      rouletteCurrentId: json['rouletteCurrentId'] == null ? null : '${json['rouletteCurrentId']}',
      rouletteLastRevealId: json['rouletteLastRevealId'] == null ? null : '${json['rouletteLastRevealId']}',
      rouletteLastPickedId: json['rouletteLastPickedId'] == null ? null : '${json['rouletteLastPickedId']}',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'key': key,
      'sheetName': sheetName,
      'title': title,
      'activityCount': activityCount,
      'extraCount': extraCount,
      'students': students.map((e) => e.toJson()).toList(),
      'roulettePickedIds': roulettePickedIds,
      'rouletteCurrentId': rouletteCurrentId,
      'rouletteLastRevealId': rouletteLastRevealId,
      'rouletteLastPickedId': rouletteLastPickedId,
    };
  }

  void normalize() {
    title = title.trim().isEmpty ? 'Turma' : title.trim();
    sheetName = sanitizeSheetName(sheetName.trim().isEmpty ? title : sheetName);
    activityCount = activityCount.clamp(1, 10);
    extraCount = extraCount.clamp(1, 10);
    for (final student in students) {
      student.normalize();
    }
    students.sort((a, b) => normalizeText(a.name).compareTo(normalizeText(b.name)));
    final validIds = students.map((e) => e.id).toSet();
    roulettePickedIds = roulettePickedIds.where(validIds.contains).toList();
    if (rouletteCurrentId != null && !validIds.contains(rouletteCurrentId)) {
      rouletteCurrentId = null;
    }
    if (rouletteLastRevealId != null && !validIds.contains(rouletteLastRevealId)) {
      rouletteLastRevealId = null;
    }
    if (rouletteLastPickedId != null && !validIds.contains(rouletteLastPickedId)) {
      rouletteLastPickedId = null;
    }
  }
}

class StudentRecord {
  StudentRecord({
    required this.id,
    required this.number,
    required this.code,
    required this.name,
    required this.status,
    required this.notes,
    required this.avs,
    required this.extras,
    required this.extraApplied,
  });

  String id;
  int number;
  String code;
  String name;
  String status;
  List<double?> notes;
  List<double?> avs;
  List<double?> extras;
  List<double> extraApplied;

  factory StudentRecord.fromJson(Map<String, dynamic> json) {
    return StudentRecord(
      id: '${json['id'] ?? ''}',
      number: _toInt(json['number']),
      code: '${json['code'] ?? ''}',
      name: '${json['name'] ?? ''}',
      status: '${json['status'] ?? 'CURSANDO'}',
      notes: _toNullableDoubleList(json['notes'], 10),
      avs: _toNullableDoubleList(json['avs'], 3),
      extras: _toNullableDoubleList(json['extras'], 10),
      extraApplied: _toDoubleList(json['extraApplied'], 3),
    )..normalize();
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'number': number,
      'code': code,
      'name': name,
      'status': status,
      'notes': notes,
      'avs': avs,
      'extras': extras,
      'extraApplied': extraApplied,
    };
  }

  void normalize() {
    if (id.trim().isEmpty) {
      id = 'student_${DateTime.now().microsecondsSinceEpoch}_${Random().nextInt(9999)}';
    }
    if (notes.length != 10) {
      notes = _resizeNullable(notes, 10);
    }
    if (avs.length != 3) {
      avs = _resizeNullable(avs, 3);
    }
    if (extras.length != 10) {
      extras = _resizeNullable(extras, 10);
    }
    if (extraApplied.length != 3) {
      extraApplied = _resizeDouble(extraApplied, 3);
    }
  }

  bool hasAnyActivityGrade(int count) {
    final limit = count.clamp(1, 10);
    for (var i = 0; i < limit; i++) {
      if (notes[i] != null) return true;
    }
    return false;
  }

  bool hasAnyAvGrade() {
    for (var i = 0; i < 3; i++) {
      if (avs[i] != null) return true;
    }
    return false;
  }

  double? activityAverageOrNull(int count) {
    if (!hasAnyActivityGrade(count)) return null;
    final limit = count.clamp(1, 10);
    var total = 0.0;
    for (var i = 0; i < limit; i++) {
      total += notes[i] ?? 0.0;
    }
    return total / limit;
  }

  double activityAverage(int count) => activityAverageOrNull(count) ?? 0.0;

  double? avAverageOrNull() {
    if (!hasAnyAvGrade()) return null;
    var total = 0.0;
    for (var i = 0; i < 3; i++) {
      total += avs[i] ?? 0.0;
    }
    return total / 3;
  }

  double avAverage() => avAverageOrNull() ?? 0.0;

  double extraTotal(int count) {
    final limit = count.clamp(1, 10);
    var total = 0.0;
    for (var i = 0; i < limit; i++) {
      total += extras[i] ?? 0.0;
    }
    return round2(total);
  }
}

class RankedStudent {
  RankedStudent({
    required this.student,
    required this.avAverage,
    required this.activityAverage,
    required this.gender,
  });

  final StudentRecord student;
  final double avAverage;
  final double activityAverage;
  final String gender;
}

class ClassSummary {
  ClassSummary({
    required this.totalStudents,
    required this.approvedCount,
    required this.recoveryCount,
    required this.approvedMale,
    required this.approvedFemale,
    required this.approvedMalePct,
    required this.approvedFemalePct,
    required this.ranked,
  });

  factory ClassSummary.empty() => ClassSummary(
        totalStudents: 0,
        approvedCount: 0,
        recoveryCount: 0,
        approvedMale: 0,
        approvedFemale: 0,
        approvedMalePct: 0,
        approvedFemalePct: 0,
        ranked: const [],
      );

  final int totalStudents;
  final int approvedCount;
  final int recoveryCount;
  final int approvedMale;
  final int approvedFemale;
  final double approvedMalePct;
  final double approvedFemalePct;
  final List<RankedStudent> ranked;
}

double round2(num value) => (value * 100).roundToDouble() / 100.0;
double round1(num value) => (value * 10).roundToDouble() / 10.0;

String normalizeText(String value) {
  const replacements = {
    'á': 'a','à': 'a','â': 'a','ã': 'a','ä': 'a',
    'é': 'e','è': 'e','ê': 'e','ë': 'e',
    'í': 'i','ì': 'i','î': 'i','ï': 'i',
    'ó': 'o','ò': 'o','ô': 'o','õ': 'o','ö': 'o',
    'ú': 'u','ù': 'u','û': 'u','ü': 'u',
    'ç': 'c',
    'Á': 'a','À': 'a','Â': 'a','Ã': 'a','Ä': 'a',
    'É': 'e','È': 'e','Ê': 'e','Ë': 'e',
    'Í': 'i','Ì': 'i','Î': 'i','Ï': 'i',
    'Ó': 'o','Ò': 'o','Ô': 'o','Õ': 'o','Ö': 'o',
    'Ú': 'u','Ù': 'u','Û': 'u','Ü': 'u',
    'Ç': 'c',
  };
  final buffer = StringBuffer();
  for (final rune in value.runes) {
    final char = String.fromCharCode(rune);
    buffer.write(replacements[char] ?? char);
  }
  return buffer.toString().toLowerCase().trim();
}

String buildClassKey(String value) {
  final normalized = normalizeText(value)
      .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
      .replaceAll(RegExp(r'_+'), '_')
      .replaceAll(RegExp(r'^_|_$'), '');
  return normalized.isEmpty ? 'turma' : normalized;
}

String sanitizeSheetName(String value, {String fallback = 'Turma'}) {
  var next = value.trim();
  if (next.isEmpty) next = fallback;
  next = next.replaceAll(RegExp(r'[\\/*?:\[\]]'), ' ');
  next = next.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (next.isEmpty) next = fallback;
  if (next.length > 31) {
    next = next.substring(0, 31).trimRight();
  }
  return next.isEmpty ? fallback : next;
}

String inferGenderFromName(String fullName) {
  final first = normalizeText(fullName)
          .split(RegExp(r'\s+'))
          .where((e) => e.isNotEmpty)
          .cast<String?>()
          .firstOrNull ??
      '';
  if (first.isEmpty) return 'male';
  const femaleStrong = {
    'ana','maria','mariana','beatriz','bianca','bruna','camila','clara','daisy','daniela','eduarda','eloa',
    'ester','fernanda','gabriela','geovanna','geovanny','giovana','heloisa','helena','ingrid','isabela',
    'isadora','julia','juliana','karina','lara','laura','leticia','lorena','luana','luisa','manuela',
    'melissa','nicole','patricia','paula','priscila','raquel','rebeca','sabrina','sarah','sophia',
    'sofia','sthefany','thammy','valentina','vitoria','yasmin','yasmim','kauane','rhayelly','mirele',
    'emanuelly','gabrielly','rosalina','peach'
  };
  const maleStrong = {
    'joao','pedro','carlos','breno','davi','davy','gabriel','guilherme','fernando','erick','murilo',
    'igor','ighor','juan','lucius','romulo','ruan','adilio','bryan','elias','geovanny','isaac','italo',
    'jamil','jorge','leonardo','lucas','marcos','osorio','vanderson','wellington','wendrel','yan','arthur',
    'anderson','andre','emanuel','emanuelly','caue','abraao','alex','antonio','gustavo','ryan'
  };
  if (femaleStrong.contains(first)) return 'female';
  if (maleStrong.contains(first)) return 'male';
  if (first.endsWith('a') && !first.endsWith('ca') && !first.endsWith('ta')) return 'female';
  return 'male';
}

ClassSummary computeClassSummary(SchoolClass schoolClass) {
  final approved = <StudentRecord>[];
  final ranked = schoolClass.students
      .where((student) => student.hasAnyAvGrade())
      .map((student) => RankedStudent(
            student: student,
            avAverage: student.avAverageOrNull() ?? 0.0,
            activityAverage: student.activityAverageOrNull(schoolClass.activityCount) ?? 0.0,
            gender: inferGenderFromName(student.name),
          ))
      .toList()
    ..sort((a, b) {
      if (b.avAverage != a.avAverage) return b.avAverage.compareTo(a.avAverage);
      if (b.activityAverage != a.activityAverage) return b.activityAverage.compareTo(a.activityAverage);
      return a.student.number.compareTo(b.student.number);
    });

  for (final rankedStudent in ranked) {
    if (rankedStudent.avAverage >= 6.0) {
      approved.add(rankedStudent.student);
    }
  }

  final approvedMale = approved.where((student) => inferGenderFromName(student.name) == 'male').length;
  final approvedFemale = approved.where((student) => inferGenderFromName(student.name) == 'female').length;
  final approvedCount = approved.length;

  return ClassSummary(
    totalStudents: schoolClass.students.length,
    approvedCount: approvedCount,
    recoveryCount: max(0, schoolClass.students.length - approvedCount),
    approvedMale: approvedMale,
    approvedFemale: approvedFemale,
    approvedMalePct: approvedCount == 0 ? 0 : (approvedMale / approvedCount) * 100,
    approvedFemalePct: approvedCount == 0 ? 0 : (approvedFemale / approvedCount) * 100,
    ranked: ranked.take(3).toList(),
  );
}

DateTime? _tryParseDate(dynamic value) {
  if (value == null) return null;
  return DateTime.tryParse('$value');
}

int _toInt(dynamic value, {int fallback = 0}) {
  if (value == null) return fallback;
  if (value is int) return value;
  if (value is double) return value.round();
  return int.tryParse('$value') ?? fallback;
}

double? _toNullableDouble(dynamic value) {
  if (value == null) return null;
  if (value is num) return value.toDouble();
  final raw = '$value'.trim().replaceAll(',', '.');
  if (raw.isEmpty || raw == '-' || raw.toLowerCase() == 'null') return null;
  return double.tryParse(raw);
}

List<double?> _toNullableDoubleList(dynamic raw, int len) {
  final source = <double?>[];
  if (raw is List) {
    for (final item in raw) {
      source.add(_toNullableDouble(item));
    }
  }
  return _resizeNullable(source, len);
}

List<double> _toDoubleList(dynamic raw, int len) {
  final source = <double>[];
  if (raw is List) {
    for (final item in raw) {
      source.add(_toNullableDouble(item) ?? 0);
    }
  }
  return _resizeDouble(source, len);
}

List<double?> _resizeNullable(List<double?> list, int len) {
  final next = List<double?>.filled(len, null, growable: true);
  for (var i = 0; i < min(len, list.length); i++) {
    next[i] = list[i];
  }
  return next;
}

List<double> _resizeDouble(List<double> list, int len) {
  final next = List<double>.filled(len, 0, growable: true);
  for (var i = 0; i < min(len, list.length); i++) {
    next[i] = list[i];
  }
  return next;
}

String _nextUniqueKey(Set<String> usedKeys, String preferredKey, String fallbackTitle) {
  final base = buildClassKey(preferredKey.trim().isEmpty ? fallbackTitle : preferredKey);
  var candidate = base;
  var counter = 2;
  while (usedKeys.contains(candidate)) {
    candidate = '${base}_$counter';
    counter++;
  }
  return candidate;
}

String _nextUniqueSheetName(Set<String> usedSheets, String preferredSheet) {
  final base = sanitizeSheetName(preferredSheet);
  var candidate = base;
  var counter = 2;
  while (usedSheets.contains(candidate)) {
    final suffix = ' $counter';
    final trimmedBase = base.length + suffix.length > 31
        ? base.substring(0, max(1, 31 - suffix.length)).trimRight()
        : base;
    candidate = sanitizeSheetName('$trimmedBase$suffix');
    counter++;
  }
  return candidate;
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
