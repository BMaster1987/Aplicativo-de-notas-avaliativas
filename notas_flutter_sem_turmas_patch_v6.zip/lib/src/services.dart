
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:hive_ce/hive.dart';
import 'package:hive_ce_flutter/adapters.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'models.dart';

class BackupEntry {
  const BackupEntry({
    required this.slot,
    required this.savedAt,
  });
  final int slot;
  final DateTime savedAt;

  String get label {
    final h = savedAt.hour.toString().padLeft(2, '0');
    final m = savedAt.minute.toString().padLeft(2, '0');
    final s = savedAt.second.toString().padLeft(2, '0');
    final d = '${savedAt.day.toString().padLeft(2, '0')}/${savedAt.month.toString().padLeft(2, '0')}';
    return '$d  $h:$m:$s';
  }
}

class LocalDatabaseService {
  static const _boxName = 'notas_local_box_v2_clean';
  static const _key = 'app_state_v2_clean';
  static const _bk0     = 'backup_slot_0_v2_clean';
  static const _bk1     = 'backup_slot_1_v2_clean';
  static const _bk0Time = 'backup_slot_0_time_v2_clean';
  static const _bk1Time = 'backup_slot_1_time_v2_clean';

  late final Box<String> _box;

  Future<void> init() async {
    await Hive.initFlutter('notas_flutter');
    _box = await Hive.openBox<String>(_boxName);
  }

  Future<AppStateData> loadState() async {
    final raw = _box.get(_key);
    if (raw == null || raw.trim().isEmpty) return loadSeedState();
    try {
      return AppStateData.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return loadSeedState();
    }
  }

  Future<void> saveState(AppStateData state) async {
    await _box.put(_key, jsonEncode(state.toJson()));
  }

  /// Rotaciona os 2 slots de backup: slot_0 → mais recente, slot_1 → anterior
  Future<void> saveBackup(AppStateData state) async {
    final existing0 = _box.get(_bk0);
    final existing0Time = _box.get(_bk0Time);
    if (existing0 != null && existing0Time != null) {
      await _box.put(_bk1, existing0);
      await _box.put(_bk1Time, existing0Time);
    }
    await _box.put(_bk0, jsonEncode(state.toJson()));
    await _box.put(_bk0Time, DateTime.now().toIso8601String());
  }

  Future<List<BackupEntry>> getBackupList() async {
    final result = <BackupEntry>[];
    for (final pair in [(_bk0, _bk0Time, 0), (_bk1, _bk1Time, 1)]) {
      final raw = _box.get(pair.$1);
      final timeStr = _box.get(pair.$2);
      if (raw != null && timeStr != null) {
        final savedAt = DateTime.tryParse(timeStr) ?? DateTime.now();
        result.add(BackupEntry(slot: pair.$3, savedAt: savedAt));
      }
    }
    return result;
  }

  Future<AppStateData> restoreBackup(int slot) async {
    final key = slot == 0 ? _bk0 : _bk1;
    final raw = _box.get(key);
    if (raw == null) throw Exception('Backup slot $slot não encontrado');
    return AppStateData.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  Future<void> clear() async => _box.delete(_key);

  static Future<AppStateData> loadSeedState() async {
    // Estado vazio — sem dependência de arquivo JSON externo
    return AppStateData(
      appVersion: '4.0.0',
      activeClassKey: '',
      updatedAt: DateTime.now(),
      muted: false,
      classes: [],
      subTabByClass: {},
    )..normalize();
  }
}

class PickedFileData {
  PickedFileData({
    required this.name,
    required this.bytes,
    required this.extension,
  });

  final String name;
  final Uint8List bytes;
  final String extension;
}

class AppFileService {
  Future<PickedFileData?> pickImportFile() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: false,
      withData: true,
      type: FileType.custom,
      allowedExtensions: const ['json', 'xlsx', 'xls'],
    );
    if (result == null || result.files.isEmpty) return null;
    final file = result.files.single;
    Uint8List? bytes = file.bytes;
    if (bytes == null && file.path != null) {
      bytes = await File(file.path!).readAsBytes();
    }
    if (bytes == null) return null;
    final extension = (file.extension ?? file.name.split('.').last).toLowerCase();
    return PickedFileData(name: file.name, bytes: bytes, extension: extension);
  }

  Future<String?> saveBytes({
    required Uint8List bytes,
    required String suggestedName,
    required String mimeType,
    String shareText = 'Arquivo exportado pelo app de notas.',
  }) async {
    final ext = suggestedName.split('.').last.toLowerCase();
    if (!kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      final target = await FilePicker.platform.saveFile(
        dialogTitle: 'Salvar arquivo exportado',
        fileName: suggestedName,
        type: FileType.custom,
        allowedExtensions: [ext],
      );
      if (target == null || target.trim().isEmpty) {
        return null;
      }
      final file = File(target);
      await file.create(recursive: true);
      await file.writeAsBytes(bytes, flush: true);
      return file.path;
    }

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$suggestedName');
    await file.writeAsBytes(bytes, flush: true);
    await SharePlus.instance.share(
      ShareParams(
        files: [XFile(file.path, mimeType: mimeType)],
        text: shareText,
        title: suggestedName,
      ),
    );
    return file.path;
  }

  Uint8List buildJson(AppStateData state) {
    final map = state.toJson();
    map['exportedAt'] = DateTime.now().toIso8601String();
    return Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(map)));
  }

  Future<AppStateData> importJson(Uint8List bytes, AppStateData current) async {
    final imported = AppStateData.fromJson(
      jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>,
    );
    return _mergeImportedState(current, imported);
  }

  Uint8List buildExcel(AppStateData state) {
    final excel = Excel.createExcel();
    final defaultSheet = excel.getDefaultSheet();
    if (defaultSheet != null) {
      excel.delete(defaultSheet);
    }

    for (final schoolClass in state.classes) {
      final sheet = excel[schoolClass.sheetName];
      final headers = <CellValue>[
        TextCellValue('Nº'),
        TextCellValue('CÓDIGO'),
        TextCellValue('NOME'),
        TextCellValue('SITUAÇÃO'),
        TextCellValue('QTDE ATIVIDADES'),
        for (var i = 0; i < 10; i++) TextCellValue('ATV ${i + 1}'),
        TextCellValue('MÉDIA ATIVIDADES'),
        TextCellValue('AV1'),
        TextCellValue('AV2'),
        TextCellValue('AV3'),
        TextCellValue('MÉDIA AVS'),
        TextCellValue('QTDE EXTRAS'),
        for (var i = 0; i < 10; i++) TextCellValue('EXTRA ${i + 1}'),
        TextCellValue('TOTAL EXTRAS'),
        TextCellValue('EXTRA APLICADO AV1'),
        TextCellValue('EXTRA APLICADO AV2'),
        TextCellValue('EXTRA APLICADO AV3'),
        TextCellValue('ROULETTE JÁ SAIU'),
      ];

      sheet.appendRow([
        TextCellValue('Turma'),
        TextCellValue(schoolClass.title),
        TextCellValue('Exportado em'),
        TextCellValue(DateTime.now().toIso8601String()),
      ]);
      sheet.appendRow([
        TextCellValue('Quantidade de atividades'),
        IntCellValue(schoolClass.activityCount),
        TextCellValue('Quantidade de pontos extras'),
        IntCellValue(schoolClass.extraCount),
      ]);
      sheet.appendRow(headers);

      for (final student in schoolClass.students) {
        sheet.appendRow([
          IntCellValue(student.number),
          TextCellValue(student.code),
          TextCellValue(student.name),
          TextCellValue(student.status),
          IntCellValue(schoolClass.activityCount),
          for (final value in student.notes)
            value == null ? TextCellValue('') : DoubleCellValue(value),
          student.activityAverageOrNull(schoolClass.activityCount) == null
              ? TextCellValue('')
              : DoubleCellValue(round2(student.activityAverageOrNull(schoolClass.activityCount)!)),
          for (final value in student.avs)
            value == null ? TextCellValue('') : DoubleCellValue(round2(value)),
          student.avAverageOrNull() == null
              ? TextCellValue('')
              : DoubleCellValue(round2(student.avAverageOrNull()!)),
          IntCellValue(schoolClass.extraCount),
          for (final value in student.extras)
            value == null ? TextCellValue('') : DoubleCellValue(round2(value)),
          DoubleCellValue(round2(student.extraTotal(schoolClass.extraCount))),
          DoubleCellValue(round2(student.extraApplied[0])),
          DoubleCellValue(round2(student.extraApplied[1])),
          DoubleCellValue(round2(student.extraApplied[2])),
          TextCellValue(schoolClass.roulettePickedIds.contains(student.id) ? 'SIM' : 'NÃO'),
        ]);
      }
    }

    return Uint8List.fromList(excel.save() ?? const <int>[]);
  }

  Future<AppStateData> importExcel(Uint8List bytes, AppStateData current) async {
    final workbook = Excel.decodeBytes(bytes);
    final next = current.clone();

    for (final entry in workbook.tables.entries) {
      final table = entry.value;
      if (table.maxRows == 0) continue;

      final rows = table.rows.map((row) => row.map((cell) => cell?.value).toList()).toList();
      if (rows.length < 2) continue;

      final importedTitle = _extractImportedClassTitle(rows, entry.key);
      final targetClass = next.findClassForImport(
            title: importedTitle,
            sheetName: entry.key,
          ) ??
          next.createClass(
            title: importedTitle,
            preferredSheetName: entry.key,
          );

      int headerRowIndex = -1;
      for (var i = 0; i < rows.length; i++) {
        final rowText = rows[i].map((e) => normalizeText('${e ?? ''}')).toList();
        if (rowText.contains('nome aluno') || rowText.contains('nome') || rowText.contains('media avs')) {
          headerRowIndex = i;
          break;
        }
      }
      if (headerRowIndex == -1) continue;

      final headers = rows[headerRowIndex].map((e) => normalizeText('${e ?? ''}')).toList();

      final activityIndex = _findHeader(headers, ['qtde atividades', 'quantidade de atividades']);
      final extraCountIndex = _findHeader(headers, ['qtde extras', 'quantidade de pontos extras']);
      final nameIndex = _findHeader(headers, ['nome aluno', 'nome']);
      final codeIndex = _findHeader(headers, ['codigo aluno', 'codigo']);
      final numberIndex = _findHeader(headers, ['nº', 'no', 'numero']);
      final statusIndex = _findHeader(headers, ['situacao']);
      final av1Index = _findHeader(headers, ['av1']);
      final av2Index = _findHeader(headers, ['av2']);
      final av3Index = _findHeader(headers, ['av3']);
      final extraApplied1Index = _findHeader(headers, ['extra aplicado av1']);
      final extraApplied2Index = _findHeader(headers, ['extra aplicado av2']);
      final extraApplied3Index = _findHeader(headers, ['extra aplicado av3']);
      final rouletteIndex = _findHeader(headers, ['roulette ja saiu']);
      final activityStart = _findHeader(headers, ['atv 1']);
      final extraStart = _findHeader(headers, ['extra 1']);

      if (nameIndex == null) continue;

      final importedStudents = <StudentRecord>[];
      final pickedIds = <String>[];
      final timestamp = DateTime.now().microsecondsSinceEpoch;
      for (var rowIndex = headerRowIndex + 1; rowIndex < rows.length; rowIndex++) {
        final row = rows[rowIndex];
        final name = _stringAt(row, nameIndex);
        if (name.trim().isEmpty) continue;
        final student = StudentRecord(
          id: '${targetClass.key}_${timestamp}_$rowIndex',
          number: _intAt(row, numberIndex),
          code: _stringAt(row, codeIndex),
          name: name,
          status: _stringAt(row, statusIndex, fallback: 'CURSANDO'),
          notes: List<double?>.filled(10, null),
          avs: [
            _doubleAt(row, av1Index),
            _doubleAt(row, av2Index),
            _doubleAt(row, av3Index),
          ],
          extras: List<double?>.filled(10, null),
          extraApplied: [
            _doubleAt(row, extraApplied1Index) ?? 0,
            _doubleAt(row, extraApplied2Index) ?? 0,
            _doubleAt(row, extraApplied3Index) ?? 0,
          ],
        );

        if (activityStart != null) {
          for (var i = 0; i < 10; i++) {
            final index = activityStart + i;
            if (index < row.length) {
              student.notes[i] = _toNullableDouble(row[index]);
            }
          }
        }
        if (extraStart != null) {
          for (var i = 0; i < 10; i++) {
            final index = extraStart + i;
            if (index < row.length) {
              student.extras[i] = _toNullableDouble(row[index]);
            }
          }
        }
        student.normalize();

        if (normalizeText(_stringAt(row, rouletteIndex)) == 'sim') {
          pickedIds.add(student.id);
        }
        importedStudents.add(student);
      }

      if (importedStudents.isNotEmpty) {
        targetClass.title = importedTitle;
        targetClass.sheetName = sanitizeSheetName(entry.key, fallback: importedTitle);
        targetClass.students = importedStudents;
        targetClass.activityCount = _intFromTopRows(rows, 0, 1) ??
            _intFromTopRows(rows, 1, 1) ??
            (activityIndex == null
                ? targetClass.activityCount
                : _intAt(
                    rows[headerRowIndex + 1],
                    activityIndex,
                    fallback: targetClass.activityCount,
                  ));
        targetClass.extraCount = _intFromTopRows(rows, 1, 3) ??
            (extraCountIndex == null
                ? targetClass.extraCount
                : _intAt(
                    rows[headerRowIndex + 1],
                    extraCountIndex,
                    fallback: targetClass.extraCount,
                  ));
        targetClass.roulettePickedIds = pickedIds;
        targetClass.rouletteCurrentId = null;
        targetClass.rouletteLastRevealId = null;
        targetClass.rouletteLastPickedId = null;
        targetClass.normalize();
      }
    }

    next.normalize();
    return next;
  }

  AppStateData _mergeImportedState(AppStateData current, AppStateData imported) {
    final next = current.clone();

    for (final importedClass in imported.classes) {
      final clonedClass = SchoolClass.fromJson(importedClass.toJson());
      final target = next.findClassForImport(
        key: clonedClass.key,
        title: clonedClass.title,
        sheetName: clonedClass.sheetName,
      );

      if (target == null) {
        final uniqueClass = SchoolClass.fromJson(clonedClass.toJson());
        uniqueClass.key = buildClassKey(clonedClass.title);
        uniqueClass.sheetName = sanitizeSheetName(clonedClass.sheetName, fallback: clonedClass.title);
        next.classes.add(uniqueClass);
        next.subTabByClass[uniqueClass.key] = imported.subTabByClass[clonedClass.key] ?? 'activities';
      } else {
        target.title = clonedClass.title;
        target.sheetName = clonedClass.sheetName;
        target.activityCount = clonedClass.activityCount;
        target.extraCount = clonedClass.extraCount;
        target.students = clonedClass.students;
        target.roulettePickedIds = clonedClass.roulettePickedIds;
        target.rouletteCurrentId = clonedClass.rouletteCurrentId;
        target.rouletteLastRevealId = clonedClass.rouletteLastRevealId;
        target.rouletteLastPickedId = clonedClass.rouletteLastPickedId;
      }
    }

    next.appVersion = imported.appVersion;
    next.updatedAt = DateTime.now();
    next.normalize();
    return next;
  }

  String _extractImportedClassTitle(List<List<dynamic>> rows, String sheetName) {
    for (final row in rows.take(3)) {
      for (var col = 0; col < row.length - 1; col++) {
        final current = normalizeText('${row[col] ?? ''}');
        if (current == 'turma' || current == 'classe') {
          final nextValue = _stringAt(row, col + 1).trim();
          if (nextValue.isNotEmpty) {
            return nextValue;
          }
        }
      }
    }
    return sheetName.trim().isEmpty ? 'Turma importada' : sheetName.trim();
  }

  int? _findHeader(List<String> headers, List<String> possibilities) {
    for (final possibility in possibilities) {
      final index = headers.indexOf(normalizeText(possibility));
      if (index != -1) return index;
    }
    return null;
  }

  String _stringAt(List<dynamic> row, int? index, {String fallback = ''}) {
    if (index == null || index < 0 || index >= row.length) return fallback;
    final value = row[index];
    if (value == null) return fallback;
    if (value is TextCellValue) return value.value.text ?? fallback;
    if (value is FormulaCellValue) return value.formula ?? fallback;
    return '$value';
  }

  int _intAt(List<dynamic> row, int? index, {int fallback = 0}) {
    if (index == null || index < 0 || index >= row.length) return fallback;
    final raw = _toNullableDouble(row[index]);
    return raw?.round() ?? fallback;
  }

  int? _intFromTopRows(List<List<dynamic>> rows, int rowIndex, int colIndex) {
    if (rowIndex >= rows.length || colIndex >= rows[rowIndex].length) return null;
    return _toNullableDouble(rows[rowIndex][colIndex])?.round();
  }

  double? _doubleAt(List<dynamic> row, int? index) {
    if (index == null || index < 0 || index >= row.length) return null;
    return _toNullableDouble(row[index]);
  }
}

double? _toNullableDouble(dynamic value) {
  if (value == null) return null;
  if (value is TextCellValue) {
    final raw = (value.value.text ?? '').trim().replaceAll(',', '.');
    if (raw.isEmpty || raw == '-') return null;
    return double.tryParse(raw);
  }
  if (value is IntCellValue) return value.value.toDouble();
  if (value is DoubleCellValue) return value.value;
  if (value is FormulaCellValue) {
    final raw = (value.formula ?? '').trim().replaceAll(',', '.');
    return double.tryParse(raw);
  }
  if (value is num) return value.toDouble();
  final raw = '$value'.trim().replaceAll(',', '.');
  if (raw.isEmpty || raw == '-') return null;
  return double.tryParse(raw);
}
