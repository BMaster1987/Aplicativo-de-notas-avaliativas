
import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:video_player_media_kit/video_player_media_kit.dart';

import 'src/app_controller.dart';
import 'src/models.dart';
import 'src/services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  VideoPlayerMediaKit.ensureInitialized(android: true, windows: true);
  runApp(const NotasFlutterApp());
}

class NotasFlutterApp extends StatelessWidget {
  const NotasFlutterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notas Flutter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF051019),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF31C8FF),
          brightness: Brightness.dark,
          surface: const Color(0xFF0B1724),
        ),
        snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
      ),
      home: const NotasHomePage(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Home Page
// ═══════════════════════════════════════════════════════════════
class NotasHomePage extends StatefulWidget {
  const NotasHomePage({super.key});

  @override
  State<NotasHomePage> createState() => _NotasHomePageState();
}

class _NotasHomePageState extends State<NotasHomePage> {
  late final AppController controller;
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _numberController = TextEditingController();
  final TextEditingController _codeController   = TextEditingController();
  final TextEditingController _nameController   = TextEditingController();
  final Set<String> _expandedStudentNames = <String>{};

  @override
  void initState() {
    super.initState();
    controller = AppController(
      databaseService: LocalDatabaseService(),
      fileService: AppFileService(),
      mediaService: MediaService(),
    );
    controller.addListener(_onChanged);
    controller.init();
  }

  void _onChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    controller.removeListener(_onChanged);
    _searchController.dispose();
    _numberController.dispose();
    _codeController.dispose();
    _nameController.dispose();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (controller.loading || controller.state == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final schoolClass = controller.activeClassOrNull;
    final summary = controller.activeSummary;

    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(child: _ThunderBackground()),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(context),
                _buildClassTabs(),
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final isWide = constraints.maxWidth >= 1100;
                      return SingleChildScrollView(
                        padding: EdgeInsets.symmetric(
                          horizontal: isWide ? 24 : 14, vertical: 12,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildStatusBar(),
                            const SizedBox(height: 12),
                            if (schoolClass == null) ...[
                              _buildEmptyWorkspace(),
                            ] else ...[
                              _buildDashboard(summary),
                              const SizedBox(height: 18),
                              _buildToolbar(schoolClass),
                              const SizedBox(height: 14),
                              _buildSubTabs(schoolClass),
                              const SizedBox(height: 12),
                              _buildCurrentTabContent(schoolClass),
                            ],
                            const SizedBox(height: 32),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          if (controller.activeOverlayMedia != null)
            Positioned.fill(
              child: IgnorePointer(
                ignoring: true,
                child: _CelebrationOverlay(controller: controller),
              ),
            ),
        ],
      ),
    );
  }

  // ── Header ────────────────────────────────────────────
  Widget _buildHeader(BuildContext context) {
    final isCompact = MediaQuery.of(context).size.width < 760;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
      child: Container(
        padding: EdgeInsets.all(isCompact ? 10 : 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: const LinearGradient(colors: [Color(0xFF0E2032), Color(0xFF091522)]),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
          boxShadow: [BoxShadow(color: const Color(0xFF31C8FF).withOpacity(0.12), blurRadius: 28)],
        ),
        child: Column(
          children: [
            Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              alignment: WrapAlignment.spaceBetween,
              runSpacing: 10,
              spacing: 10,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset('assets/images/title_art.png',
                        height: isCompact ? 64 : 80, fit: BoxFit.contain),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isCompact ? 'Notas Flutter' : 'Notas Flutter • Banco local',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w900, letterSpacing: 0.4),
                        ),
                        const SizedBox(height: 3),
                        Text('Atividades • AVs • Pontos extras • Roleta • Ranking',
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white60)),
                      ],
                    ),
                  ],
                ),
                // Botões do header — menores para caber o de backup
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _SmallBtn(
                      icon: Icons.file_open_rounded,
                      label: 'Importar',
                      onPressed: controller.importFromFile,
                    ),
                    _SmallBtn(
                      icon: Icons.history_rounded,
                      label: 'Backups',
                      onPressed: _showBackupDialog,
                      color: const Color(0xFFFFA726),
                    ),
                    _SmallBtn(
                      icon: Icons.grid_on_rounded,
                      label: 'Excel',
                      onPressed: controller.hasClasses ? controller.exportExcel : null,
                    ),
                    _SmallBtn(
                      icon: Icons.data_object_rounded,
                      label: 'JSON',
                      onPressed: controller.exportJson,
                    ),
                    IconButton.filledTonal(
                      tooltip: controller.currentState.muted ? 'Ativar sons' : 'Silenciar',
                      onPressed: () => controller.setMuted(!controller.currentState.muted),
                      icon: Icon(controller.currentState.muted
                          ? Icons.volume_off_rounded : Icons.volume_up_rounded),
                    ),
                    IconButton.filledTonal(
                      tooltip: 'Apagar tudo',
                      onPressed: _confirmClearAll,
                      icon: const Icon(Icons.delete_forever_rounded),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8, runSpacing: 6,
              children: const [
                _LegendBadge(emoji: '😄', text: 'Atv 10,0'),
                _LegendBadge(emoji: '🙂', text: 'Atv 8,0'),
                _LegendBadge(emoji: '😅', text: 'Atv 7,0'),
                _LegendBadge(emoji: '😞', text: 'Atv 6,0'),
                _LegendBadge(emoji: '🙌', text: 'AV 6–7,99'),
                _LegendBadge(emoji: '😎', text: 'AV 10,0'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Tabs de turmas ────────────────────────────────────
  Widget _buildClassTabs() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: SizedBox(
              height: 56,
              child: controller.currentState.classes.isEmpty
                  ? Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Nenhuma turma cadastrada ainda.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
                      ),
                    )
                  : ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: controller.currentState.classes.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (context, index) {
                        final sc = controller.currentState.classes[index];
                        final selected = sc.key == controller.currentState.activeClassKey;
                        return ChoiceChip(
                          selected: selected,
                          label: Text(sc.title),
                          avatar: CircleAvatar(
                            backgroundColor: Colors.black.withOpacity(0.25),
                            child: Text('${sc.students.length}', style: const TextStyle(fontSize: 12)),
                          ),
                          onSelected: (_) => controller.setActiveClass(sc.key),
                          selectedColor: const Color(0xFF31C8FF).withOpacity(0.22),
                          labelStyle: TextStyle(
                            color: Colors.white,
                            fontWeight: selected ? FontWeight.bold : FontWeight.w500,
                          ),
                        );
                      },
                    ),
            ),
          ),
          const SizedBox(width: 10),
          FilledButton.tonalIcon(
            onPressed: _openClassManagementPage,
            icon: const Icon(Icons.groups_rounded),
            label: const Text('Turmas'),
          ),
        ],
      ),
    );
  }


  Widget _buildEmptyWorkspace() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(colors: [Color(0xFF0F2236), Color(0xFF152E47)]),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
        boxShadow: [BoxShadow(color: const Color(0xFF31C8FF).withOpacity(0.10), blurRadius: 28)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Comece criando a primeira turma', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text(
            'O aplicativo agora inicia limpo, sem turmas fixas e sem dados padrão. Você pode criar, renomear e excluir turmas pelo botão Turmas. Ao excluir, o app sempre pede confirmação.',
            style: TextStyle(color: Colors.white70, height: 1.35),
          ),
          const SizedBox(height: 18),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              FilledButton.icon(
                onPressed: () => _showClassNameDialog(),
                icon: const Icon(Icons.add_rounded),
                label: const Text('Criar turma'),
              ),
              OutlinedButton.icon(
                onPressed: controller.importFromFile,
                icon: const Icon(Icons.file_open_rounded),
                label: const Text('Importar Excel ou JSON'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Status bar ────────────────────────────────────────
  Widget _buildStatusBar() {
    return _InfoCard(
      title: 'Salvamento local',
      subtitle: controller.saveStatus,
      icon: Icons.save_rounded,
      accent: const Color(0xFF31C8FF),
    );
  }

  // ── Dashboard — cards proporcionais com LayoutBuilder ──
  Widget _buildDashboard(ClassSummary summary) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Cards de stats: Row com Expanded para preencher toda a largura
        IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: _StatCard(
                  title: 'Aprovados',
                  value: '${summary.approvedCount}',
                  accent: const Color(0xFF42E695),
                  icon: Icons.verified_rounded,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _StatCard(
                  title: 'Reprovados /\nRecuperação',
                  value: '${summary.recoveryCount}',
                  accent: const Color(0xFFFF8A65),
                  icon: Icons.warning_rounded,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: _GenderPieCard(summary: summary),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        _RankingSection(controller: controller, summary: summary),
      ],
    );
  }

  // ── Toolbar ────────────────────────────────────────────
  Widget _buildToolbar(SchoolClass schoolClass) {
    return Wrap(
      spacing: 10, runSpacing: 10,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        SizedBox(
          width: max(260.0, min(420.0, MediaQuery.of(context).size.width - 48.0)),
          child: TextField(
            controller: _searchController,
            onChanged: controller.updateSearch,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search_rounded),
              hintText: 'Buscar por nome, número, código...',
              filled: true,
              fillColor: Colors.white.withOpacity(0.05),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
            ),
          ),
        ),
        FilledButton.icon(
          onPressed: () => _showStudentDialog(),
          icon: const Icon(Icons.person_add_alt_1_rounded),
          label: const Text('Adicionar aluno'),
        ),
        FilledButton.tonalIcon(
          onPressed: controller.importFromFile,
          icon: const Icon(Icons.upload_file_rounded),
          label: const Text('Importar planilha'),
        ),
        FilledButton.tonalIcon(
          onPressed: controller.exportExcel,
          icon: const Icon(Icons.download_rounded),
          label: Text('Exportar ${schoolClass.title}'),
        ),
      ],
    );
  }

  // ── Sub-tabs ───────────────────────────────────────────
  Widget _buildSubTabs(SchoolClass schoolClass) {
    final currentTab = controller.currentTabFor(schoolClass.key);
    const tabs = [
      ('activities', 'Atividades',    Icons.emoji_emotions_outlined),
      ('grades',     'AVs',           Icons.edit_note_rounded),
      ('extras',     'Pontos extras', Icons.auto_awesome_rounded),
      ('roulette',   'Roleta',        Icons.casino_rounded),
    ];
    return Wrap(
      spacing: 10, runSpacing: 10,
      children: [
        for (final item in tabs)
          ChoiceChip(
            selected: item.$1 == currentTab,
            label: Text(item.$2),
            avatar: Icon(item.$3, size: 18),
            onSelected: (_) => controller.setCurrentTab(item.$1),
            selectedColor: Colors.white.withOpacity(0.18),
            backgroundColor: Colors.white.withOpacity(0.05),
          ),
      ],
    );
  }

  Widget _buildCurrentTabContent(SchoolClass schoolClass) {
    switch (controller.currentTabFor(schoolClass.key)) {
      case 'grades':    return _buildGradesTab(schoolClass);
      case 'extras':    return _buildExtrasTab(schoolClass);
      case 'roulette':  return _buildRouletteTab(schoolClass);
      default:          return _buildActivitiesTab(schoolClass);
    }
  }

  // ── Aba Atividades ─────────────────────────────────────
  Widget _buildActivitiesTab(SchoolClass schoolClass) {
    return _SectionCard(
      title: 'Atividades',
      subtitle: 'Escolha de 1 a 10 atividades com notas por emoji. A média é aritmética.',
      actions: [
        _CountSelector(label: 'Quantidade', value: schoolClass.activityCount, onChanged: controller.setActivityCount),
        FilledButton.icon(onPressed: _confirmResetActivities, icon: const Icon(Icons.refresh_rounded), label: const Text('Resetar')),
        FilledButton.icon(
          onPressed: () => _showTransferDialog(source: TransferSource.activities),
          icon: const Icon(Icons.send_time_extension_rounded),
          label: const Text('Lançar médias nas AVs'),
        ),
      ],
      child: _buildScrollableTable(
        columns: [
          const _TableHeader('Nº', width: 72), const _TableHeader('Código', width: 120), const _TableHeader('Nome', width: 420),
          for (var i = 0; i < schoolClass.activityCount; i++) _TableHeader('Atv ${i + 1}', width: 104),
          const _TableHeader('Média', width: 96), const _TableHeader('Ações', width: 128),
        ],
        rows: controller.filteredStudents.map((student) => [
          _cellText('${student.number}'),
          _cellText(student.code),
          _cellStudentName(student),
          for (var i = 0; i < schoolClass.activityCount; i++)
            _cellButton(
              label: controller.activityEmoji(student.notes[i]),
              secondary: student.notes[i] == null ? 'vazio' : '${student.notes[i]!.toStringAsFixed(1)}',
              onTap: () => _showActivityDialog(student, i),
            ),
          _cellHighlightValue(student.activityAverageOrNull(schoolClass.activityCount)),
          _rowActions(student),
        ]).toList(),
      ),
    );
  }

  // ── Aba AVs ────────────────────────────────────────────
  Widget _buildGradesTab(SchoolClass schoolClass) {
    return _SectionCard(
      title: 'AV1 • AV2 • AV3',
      subtitle: 'Notas numéricas de 0,00 até 10,00. O emoji representa a faixa.',
      actions: [
        FilledButton.icon(onPressed: _confirmResetAvs, icon: const Icon(Icons.refresh_rounded), label: const Text('Resetar AVs')),
      ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Wrap(spacing: 8, runSpacing: 8, children: [
            _LegendBadge(emoji: '😞', text: '0,00–5,99'),
            _LegendBadge(emoji: '🙌', text: '6,00–7,99'),
            _LegendBadge(emoji: '😄', text: '8,00–9,99'),
            _LegendBadge(emoji: '😎', text: '10,00'),
          ]),
          const SizedBox(height: 12),
          _buildScrollableTable(
            columns: const [
              _TableHeader('Nº', width: 72), _TableHeader('Código', width: 120), _TableHeader('Nome', width: 420),
              _TableHeader('AV1', width: 110), _TableHeader('AV2', width: 110), _TableHeader('AV3', width: 110),
              _TableHeader('Média', width: 100), _TableHeader('Ações', width: 128),
            ],
            rows: controller.filteredStudents.map((student) => [
              _cellText('${student.number}'),
              _cellText(student.code),
              _cellStudentName(student),
              for (var i = 0; i < 3; i++)
                _cellButton(
                  label: controller.gradeEmoji(student.avs[i]),
                  secondary: student.avs[i] == null ? 'lançar' : student.avs[i]!.toStringAsFixed(2),
                  onTap: () => _showAvDialog(student, i), large: true,
                ),
              _cellHighlightValue(student.avAverageOrNull()),
              _rowActions(student),
            ]).toList(),
          ),
        ],
      ),
    );
  }

  // ── Aba Extras ─────────────────────────────────────────
  Widget _buildExtrasTab(SchoolClass schoolClass) {
    return _SectionCard(
      title: 'Pontos extras',
      subtitle: 'Escolha de 1 a 10 itens extras.',
      actions: [
        _CountSelector(label: 'Quantidade', value: schoolClass.extraCount, onChanged: controller.setExtraCount),
        FilledButton.icon(onPressed: _confirmResetExtras, icon: const Icon(Icons.refresh_rounded), label: const Text('Resetar extras')),
        FilledButton.icon(
          onPressed: () => _showTransferDialog(source: TransferSource.extras),
          icon: const Icon(Icons.send_time_extension_rounded),
          label: const Text('Somar todos nas AVs'),
        ),
      ],
      child: _buildScrollableTable(
        columns: [
          const _TableHeader('Nº', width: 72), const _TableHeader('Código', width: 120), const _TableHeader('Nome', width: 420),
          for (var i = 0; i < schoolClass.extraCount; i++) _TableHeader('Extra ${i + 1}', width: 118),
          const _TableHeader('Total', width: 96), const _TableHeader('Ações', width: 170),
        ],
        rows: controller.filteredStudents.map((student) => [
          _cellText('${student.number}'),
          _cellText(student.code),
          _cellStudentName(student),
          for (var i = 0; i < schoolClass.extraCount; i++)
            _cellButton(
              label: controller.extraEmoji(student.extras[i]),
              secondary: student.extras[i] == null ? 'vazio' : student.extras[i]!.toStringAsFixed(1),
              onTap: () => _showExtraDialog(student, i),
            ),
          _cellHighlight(student.extraTotal(schoolClass.extraCount).toStringAsFixed(2)),
          Row(children: [
            Expanded(child: _rowActions(student)),
            IconButton.filledTonal(
              tooltip: 'Somar só este aluno nas AVs',
              onPressed: () => _showTransferDialog(source: TransferSource.extras, student: student),
              icon: const Icon(Icons.add_chart_rounded),
            ),
          ]),
        ]).toList(),
      ),
    );
  }

  // ── Aba Roleta ─────────────────────────────────────────
  Widget _buildRouletteTab(SchoolClass schoolClass) {
    final selectedStudent = controller.currentRouletteStudent;
    final revealed = controller.rouletteRevealed;
    final correctDone = controller.correctCelebrated;
    final bonusDone = controller.bonusApplied;

    return _SectionCard(
      title: 'Roleta interativa',
      subtitle: 'Cada número sai apenas uma vez até o reset. Toque no número para revelar o nome.',
      actions: [
        FilledButton.icon(
          onPressed: (controller.rouletteSpinning || controller.activeOverlayMedia != null)
              ? null
              : controller.spinRoulette,
          icon: const Icon(Icons.casino_rounded),
          label: const Text('Girar roleta'),
        ),
        _RouletteStatusPanel(controller: controller),
      ],
      child: Column(
        children: [
          // ── Roda ──────────────────────────────────────
          LayoutBuilder(builder: (context, constraints) {
            final size = min(constraints.maxWidth, 760.0);
            return Center(
              child: SizedBox(
                width: size, height: size,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    AnimatedRotation(
                      turns: controller.rouletteRotation / (2 * pi),
                      duration: const Duration(milliseconds: 2800),
                      curve: Curves.easeOutCubic,
                      child: CustomPaint(
                        size: Size.square(size),
                        painter: _WheelPainter(
                          students: schoolClass.students,
                          selectedId: selectedStudent?.id,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 14,
                      child: Icon(Icons.arrow_drop_down_rounded, size: 80, color: Colors.white.withOpacity(0.95)),
                    ),
                    // Centro clicável
                    GestureDetector(
                      onTap: (selectedStudent == null || revealed) ? null : controller.revealCurrentRouletteStudent,
                      child: Container(
                        width: size * 0.26, height: size * 0.26,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(colors: [
                            revealed ? const Color(0xFF31C8FF).withOpacity(0.32) : Colors.white.withOpacity(0.18),
                            const Color(0xFF0A1625),
                          ]),
                          border: Border.all(
                            color: revealed ? const Color(0xFF31C8FF).withOpacity(0.55) : Colors.white.withOpacity(0.14),
                            width: 3,
                          ),
                          boxShadow: [BoxShadow(
                            color: const Color(0xFF31C8FF).withOpacity(revealed ? 0.45 : 0.22),
                            blurRadius: 24,
                          )],
                        ),
                        alignment: Alignment.center,
                        child: selectedStudent == null
                            ? Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
                                Icon(Icons.touch_app_rounded, size: 38),
                                SizedBox(height: 6),
                                Text('Gire', style: TextStyle(fontWeight: FontWeight.w800)),
                              ])
                            : revealed
                                ? Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
                                    Icon(Icons.check_circle_rounded, size: 36, color: Color(0xFF31C8FF)),
                                    SizedBox(height: 4),
                                    Text('Revelado!', textAlign: TextAlign.center,
                                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                                  ])
                                : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                    Text('${selectedStudent.number}',
                                        style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                                    const SizedBox(height: 4),
                                    const Text('Toque para\nrevelar',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(fontSize: 11)),
                                  ]),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),

          const SizedBox(height: 18),

          // ── Botões Acertou / Errou ─────────────────────
          // Permanecem disponíveis após revelar, inclusive com o GIF visível.
          Wrap(
            spacing: 12, runSpacing: 12, alignment: WrapAlignment.center,
            children: [
              FilledButton.tonalIcon(
                onPressed: (revealed && (controller.activeOverlayKind == null || controller.activeOverlayKind == 'reveal'))
                    ? _handleCorrect
                    : null,
                icon: const Icon(Icons.sentiment_very_satisfied_rounded),
                label: const Text('Acertou'),
              ),
              FilledButton.tonalIcon(
                onPressed: (revealed && (controller.activeOverlayKind == null || controller.activeOverlayKind == 'reveal'))
                    ? controller.celebrateWrong
                    : null,
                icon: const Icon(Icons.sentiment_dissatisfied_rounded),
                label: const Text('Errou'),
              ),
            ],
          ),

          // ── Botão Adicionar ponto ──────────────────────
          // Só aparece APÓS overlay de Acertou fechar
          if (correctDone && !bonusDone) ...[
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: () => _showRewardDialog(selectedStudent),
              icon: const Icon(Icons.add_circle_rounded),
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFF42E695).withOpacity(0.85)),
              label: Text(
                'Adicionar ponto para ${selectedStudent?.name ?? "aluno"}',
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
          if (bonusDone) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: const Color(0xFF42E695).withOpacity(0.12),
                border: Border.all(color: const Color(0xFF42E695).withOpacity(0.30)),
              ),
              child: const Text('✅ Ponto adicionado!', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ],

          const SizedBox(height: 16),
          Row(
            children: [
              FilledButton.tonalIcon(
                onPressed: _confirmResetRoulette,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Resetar roleta'),
              ),
              const Spacer(),
              FilledButton.tonalIcon(
                onPressed: controller.activeOverlayMedia != null
                    ? controller.stopOverlayPlayback
                    : null,
                icon: const Icon(Icons.stop_circle_rounded),
                label: const Text('Parar animações'),
              ),
            ],
          ),

          // ── Nome revelado ──────────────────────────────
          if (revealed && selectedStudent != null) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: const Color(0xFF31C8FF).withOpacity(0.10),
                border: Border.all(color: const Color(0xFF31C8FF).withOpacity(0.30)),
              ),
              child: Text(
                '${selectedStudent.number} • ${selectedStudent.name}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                textAlign: TextAlign.center,
              ),
            ),
          ],
          if (!revealed && selectedStudent != null) ...[
            const SizedBox(height: 14),
            Text(
              'Número ${selectedStudent.number} sorteado — toque no centro para revelar',
              style: const TextStyle(color: Colors.white54, fontSize: 13),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }

  // ── Handlers ──────────────────────────────────────────
  Future<void> _handleCorrect() async {
    await controller.celebrateCorrect();
    // "Adicionar ponto" aparece automaticamente após overlay fechar (correctCelebrated = true)
  }

  Future<void> _showRewardDialog(StudentRecord? student) async {
    if (student == null) return;
    if (controller.activeOverlayMedia != null) {
      controller.dismissOverlay();
    }
    final result = await showDialog<_RewardConfig>(
      context: context,
      builder: (context) => _RewardDialog(student: student),
    );
    if (result == null) return;
    await controller.applyRouletteReward(
      student: student, avIndex: result.avIndex, points: result.points,
    );
  }

  Future<void> _showActivityDialog(StudentRecord student, int index) async {
    const clearToken = '_clear_';
    final choice = await showModalBottomSheet<Object?>(
      context: context,
      backgroundColor: const Color(0xFF0B1724),
      builder: (context) {
        const options = [('😄', 'Muito feliz', 10.0), ('🙂', 'Feliz', 8.0), ('😅', 'Até que enfim', 7.0), ('😞', 'Decepção', 6.0)];
        return Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Atividade ${index + 1} • ${student.name}', style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              for (final item in options)
                ListTile(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  tileColor: Colors.white.withOpacity(0.05),
                  leading: Text(item.$1, style: const TextStyle(fontSize: 26)),
                  title: Text(item.$2),
                  subtitle: Text(item.$3.toStringAsFixed(1)),
                  onTap: () => Navigator.pop(context, item.$3),
                ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () => Navigator.pop(context, clearToken),
                icon: const Icon(Icons.delete_outline_rounded),
                label: const Text('Limpar valor'),
              ),
            ],
          ),
        );
      },
    );
    if (choice == null) return;
    if (choice == clearToken) {
      final confirmed = await _showConfirmDialog(
        title: 'Limpar atividade',
        message: 'Deseja apagar a nota da atividade ${index + 1} de ${student.name}?',
        confirmLabel: 'Limpar',
      );
      if (!confirmed) return;
      await controller.setActivityEmoji(student, index, null);
      return;
    }
    await controller.setActivityEmoji(student, index, choice as double);
  }

  Future<void> _showAvDialog(StudentRecord student, int index) async {
    const clearToken = '_clear_';
    final ctrl = TextEditingController(text: student.avs[index]?.toStringAsFixed(2) ?? '');
    final result = await showDialog<Object?>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('AV${index + 1} • ${student.name}'),
        content: TextField(
          controller: ctrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(hintText: 'Digite de 0,00 até 10,00'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(context, clearToken), child: const Text('Limpar')),
          FilledButton(
            onPressed: () {
              final parsed = double.tryParse(ctrl.text.replaceAll(',', '.'));
              Navigator.pop(context, parsed);
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
    if (result == null) return;
    if (result == clearToken) {
      final confirmed = await _showConfirmDialog(
        title: 'Limpar AV',
        message: 'Deseja apagar a AV${index + 1} de ${student.name}?',
        confirmLabel: 'Limpar',
      );
      if (!confirmed) return;
      await controller.setAvValue(student, index, null);
      return;
    }
    await controller.setAvValue(student, index, result as double?);
  }

  Future<void> _showExtraDialog(StudentRecord student, int index) async {
    const clearToken = '_clear_';
    final result = await showModalBottomSheet<Object?>(
      context: context,
      backgroundColor: const Color(0xFF0B1724),
      builder: (context) {
        final values = [for (double v = 0.5; v <= 5.0 + 0.0001; v += 0.5) v];
        return Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Ponto extra ${index + 1} • ${student.name}', style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              Wrap(
                spacing: 10, runSpacing: 10,
                children: [
                  for (final v in values)
                    ActionChip(
                      avatar: const Text('🙂', style: TextStyle(fontSize: 18)),
                      label: Text(v.toStringAsFixed(1)),
                      onPressed: () => Navigator.pop(context, v),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              TextButton.icon(
                onPressed: () => Navigator.pop(context, clearToken),
                icon: const Icon(Icons.delete_outline_rounded),
                label: const Text('Limpar valor'),
              ),
            ],
          ),
        );
      },
    );
    if (result == null) return;
    if (result == clearToken) {
      final confirmed = await _showConfirmDialog(
        title: 'Limpar ponto extra',
        message: 'Deseja apagar o ponto extra ${index + 1} de ${student.name}?',
        confirmLabel: 'Limpar',
      );
      if (!confirmed) return;
      await controller.setExtraValue(student, index, null);
      return;
    }
    await controller.setExtraValue(student, index, result as double);
  }

  Future<void> _showStudentDialog({StudentRecord? student}) async {
    _numberController.text = student?.number.toString() ?? '';
    _codeController.text   = student?.code ?? '';
    _nameController.text   = student?.name ?? '';
    var status = student?.status ?? 'CURSANDO';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          title: Text(student == null ? 'Adicionar aluno' : 'Editar aluno'),
          content: SizedBox(
            width: 520,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: _numberController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Número')),
                const SizedBox(height: 12),
                TextField(controller: _codeController, decoration: const InputDecoration(labelText: 'Código')),
                const SizedBox(height: 12),
                TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'Nome')),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: status,
                  items: const [
                    DropdownMenuItem(value: 'CURSANDO', child: Text('CURSANDO')),
                    DropdownMenuItem(value: 'TRANS',    child: Text('TRANS')),
                    DropdownMenuItem(value: 'REMAN',    child: Text('REMAN')),
                    DropdownMenuItem(value: 'CANCE',    child: Text('CANCE')),
                  ],
                  onChanged: (v) => setStateDialog(() => status = v ?? 'CURSANDO'),
                  decoration: const InputDecoration(labelText: 'Situação'),
                ),
              ],
            ),
          ),
          actions: [
            if (student != null)
              TextButton.icon(
                onPressed: () async {
                  Navigator.pop(context);
                  await _confirmRemoveStudent(student);
                },
                icon: const Icon(Icons.delete_outline_rounded),
                label: const Text('Remover'),
              ),
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
          ],
        ),
      ),
    );
    if (confirmed != true) return;
    await controller.addOrUpdateStudent(
      original: student,
      number: int.tryParse(_numberController.text) ?? 0,
      code: _codeController.text.trim(),
      name: _nameController.text.trim(),
      status: status,
    );
  }


  Future<bool> _showConfirmDialog({
    required String title,
    required String message,
    String confirmLabel = 'Confirmar',
    bool danger = true,
  }) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: danger
                ? FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFC62828),
                    foregroundColor: Colors.white,
                  )
                : null,
            child: Text(confirmLabel),
          ),
        ],
      ),
    );
    return confirmed == true;
  }

  Future<void> _confirmRemoveStudent(StudentRecord student) async {
    final confirmed = await _showConfirmDialog(
      title: 'Excluir aluno',
      message: 'Deseja excluir o aluno ${student.name}? Esta ação remove dados de atividades, AVs, extras e roleta.',
      confirmLabel: 'Excluir aluno',
    );
    if (!confirmed) return;
    await controller.removeStudent(student);
  }

  Future<void> _confirmResetActivities() async {
    final confirmed = await _showConfirmDialog(
      title: 'Resetar atividades',
      message: 'Deseja apagar todas as notas de atividades da turma atual?',
      confirmLabel: 'Resetar atividades',
    );
    if (!confirmed) return;
    await controller.resetActivities();
  }

  Future<void> _confirmResetAvs() async {
    final confirmed = await _showConfirmDialog(
      title: 'Resetar AVs',
      message: 'Deseja apagar todas as AVs da turma atual?',
      confirmLabel: 'Resetar AVs',
    );
    if (!confirmed) return;
    await controller.resetAvs();
  }

  Future<void> _confirmResetExtras() async {
    final confirmed = await _showConfirmDialog(
      title: 'Resetar pontos extras',
      message: 'Deseja apagar todos os pontos extras da turma atual?',
      confirmLabel: 'Resetar extras',
    );
    if (!confirmed) return;
    await controller.resetExtras();
  }

  Future<void> _confirmResetRoulette() async {
    final confirmed = await _showConfirmDialog(
      title: 'Resetar roleta',
      message: 'Deseja limpar o histórico de sorteios da roleta desta turma?',
      confirmLabel: 'Resetar roleta',
    );
    if (!confirmed) return;
    await controller.resetRoulette();
  }

  Future<void> _openClassManagementPage() async {
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _ClassManagementPage(
          controller: controller,
          onCreateRequested: () => _showClassNameDialog(),
          onRenameRequested: (schoolClass) => _showClassNameDialog(schoolClass: schoolClass),
          onDeleteRequested: (schoolClass) => _confirmRemoveClass(schoolClass),
        ),
      ),
    );
  }

  Future<void> _showClassNameDialog({SchoolClass? schoolClass}) async {
    if (!mounted) return;
    final title = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        builder: (_) => _ClassNameEditorPage(initialValue: schoolClass?.title),
      ),
    );
    if (!mounted || title == null || title.trim().isEmpty) return;

    // Aguarda a rota do editor terminar de sair da árvore antes de notificar.
    // Isso evita a assertion `_dependents.isEmpty` que estava acontecendo
    // ao salvar pelo fluxo anterior com diálogo e TextField.
    FocusManager.instance.primaryFocus?.unfocus();
    await Future<void>.delayed(const Duration(milliseconds: 30));

    if (schoolClass == null) {
      await controller.addClass(title.trim());
    } else {
      await controller.renameClass(schoolClass, title.trim());
    }
  }

  Future<void> _confirmRemoveClass(SchoolClass schoolClass) async {
    final confirmed = await _showConfirmDialog(
      title: 'Excluir turma "${schoolClass.title}"',
      message:
          'Todos os ${schoolClass.students.length} aluno(s), notas, AVs, extras e '
          'dados da roleta desta turma serão removidos.\n\nEssa ação não pode ser desfeita.',
      confirmLabel: 'Excluir turma',
    );
    if (!confirmed || !mounted) return;
    await controller.removeClass(schoolClass);
  }

  Future<void> _showTransferDialog({required TransferSource source, StudentRecord? student}) async {
    final schoolClass = controller.activeClassOrNull;
    if (schoolClass == null) return;
    final result = await showDialog<Set<int>>(
      context: context,
      barrierDismissible: true,
      builder: (context) => _TransferDialog(
        schoolClass: schoolClass, source: source, student: student,
      ),
    );
    if (result == null || result.isEmpty) return;
    if (source == TransferSource.activities) {
      await controller.exportActivitiesToAvs(result);
    } else {
      await controller.exportExtrasToAvs(result, studentId: student?.id);
    }
  }

  Future<void> _showBackupDialog() async {
    await controller.refreshBackupList();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => _BackupDialog(controller: controller),
    );
  }

  Future<void> _confirmClearAll() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Apagar todos os dados'),
        content: const Text('Remove nomes extras, notas, AVs, pontos extras e estado da roleta.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Apagar tudo')),
        ],
      ),
    );
    if (confirmed == true) await controller.clearAllData();
  }

  // ── Tabela ─────────────────────────────────────────────
  Widget _buildScrollableTable({required List<_TableHeader> columns, required List<List<Widget>> rows}) {
    return Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: Colors.black.withOpacity(0.12)),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columnSpacing: 12, horizontalMargin: 14,
          headingRowHeight: 52, dataRowMinHeight: 82, dataRowMaxHeight: 150,
          columns: [
            for (final col in columns)
              DataColumn(label: SizedBox(width: col.width, child: Text(col.label, style: const TextStyle(fontWeight: FontWeight.w900)))),
          ],
          rows: [for (final row in rows) DataRow(cells: row.map((c) => DataCell(c)).toList())],
        ),
      ),
    );
  }

  bool _isStudentNameExpanded(String studentId) => _expandedStudentNames.contains(studentId);

  void _toggleStudentName(String studentId) {
    setState(() {
      if (_expandedStudentNames.contains(studentId)) {
        _expandedStudentNames.remove(studentId);
      } else {
        _expandedStudentNames.add(studentId);
      }
    });
  }

  Widget _cellStudentName(StudentRecord student) {
    final expanded = _isStudentNameExpanded(student.id);
    return SizedBox(
      width: 420,
      child: GestureDetector(
        onDoubleTap: () => _toggleStudentName(student.id),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Text(
            student.name,
            style: const TextStyle(fontWeight: FontWeight.w700),
            maxLines: expanded ? 4 : 1,
            overflow: expanded ? TextOverflow.visible : TextOverflow.ellipsis,
            softWrap: true,
          ),
        ),
      ),
    );
  }

  Widget _cellText(String text, {FontWeight weight = FontWeight.w500}) {
    return SizedBox(width: 120, child: Text(text, style: TextStyle(fontWeight: weight), overflow: TextOverflow.ellipsis));
  }

  Widget _cellHighlight(String value, {bool muted = false}) {
    return SizedBox(
      width: 88,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: muted
              ? Colors.white.withOpacity(0.05)
              : const Color(0xFF31C8FF).withOpacity(0.14),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: muted
                ? Colors.white.withOpacity(0.06)
                : const Color(0xFF31C8FF).withOpacity(0.10),
          ),
        ),
        child: Text(
          value,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.w900,
            color: muted ? Colors.white60 : Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _cellHighlightValue(double? value) {
    if (value == null) {
      return _cellHighlight('—', muted: true);
    }
    return _cellHighlight(value.toStringAsFixed(2));
  }

  Widget _cellButton({required String label, required String secondary, required VoidCallback onTap, bool large = false}) {
    return SizedBox(
      width: 104,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: Colors.white.withOpacity(0.06),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(label, style: TextStyle(fontSize: large ? 24 : 20)),
                ),
                const SizedBox(height: 3),
                Text(
                  secondary,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 10, color: Colors.white70, height: 1.0),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _rowActions(StudentRecord student) {
    return SizedBox(
      width: 120,
      child: Row(children: [
        IconButton(tooltip: 'Editar aluno', onPressed: () => _showStudentDialog(student: student), icon: const Icon(Icons.edit_rounded)),
        IconButton(tooltip: 'Excluir aluno', onPressed: () => _confirmRemoveStudent(student), icon: const Icon(Icons.delete_outline_rounded)),
      ]),
    );
  }
}

class _RouletteStatusPanel extends StatelessWidget {
  const _RouletteStatusPanel({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final last = controller.lastRouletteStudent;
    return Container(
      constraints: const BoxConstraints(minWidth: 280, maxWidth: 420),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [
            Colors.white.withOpacity(0.11),
            const Color(0xFF0A1625).withOpacity(0.78),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: const Color(0xFF31C8FF).withOpacity(0.26)),
      ),
      child: DefaultTextStyle(
        style: const TextStyle(color: Colors.white),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: const Color(0xFF31C8FF).withOpacity(0.18),
                  ),
                  child: Text(
                    'Giros: ${controller.rouletteSpinCount}',
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              last == null
                  ? 'Último sorteado: ainda não houve sorteio'
                  : 'Último sorteado: ${last.number} • ${last.name}',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Celebration Overlay — GIF/vídeo com emojis ao redor
// ═══════════════════════════════════════════════════════════════
class _CelebrationOverlay extends StatelessWidget {
  const _CelebrationOverlay({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final media = controller.activeOverlayMedia!;
    final emojis = controller.activeOverlayEmojis;

    return LayoutBuilder(
      builder: (context, constraints) {
        final safeWidth = max(320.0, constraints.maxWidth - 24);
        final safeHeight = max(360.0, constraints.maxHeight - 24);
        final compact = safeWidth < 700 || safeHeight < 860;
        final titleFontSize = compact ? 30.0 : 38.0;
        final subtitleFontSize = compact ? 18.0 : 22.0;
        final titlePadding = compact
            ? const EdgeInsets.symmetric(horizontal: 18, vertical: 14)
            : const EdgeInsets.symmetric(horizontal: 24, vertical: 18);
        final stageSize = min(560.0, min(safeWidth * 0.94, safeHeight - (compact ? 220.0 : 250.0)));
        final clampedStageSize = stageSize.clamp(300.0, 560.0).toDouble();
        final mediaSize = clampedStageSize * 0.57;
        final orbitRadius = clampedStageSize * 0.38;
        final glowSize = clampedStageSize * 0.71;

        final orbitChildren = <Widget>[];
        final fallback = ['🎉', '🥳', '✨', '🙌', '⭐', '🔥'];
        final total = emojis.isEmpty ? fallback.length : emojis.length;
        for (var i = 0; i < total; i++) {
          final emoji = emojis.isEmpty ? fallback[i % fallback.length] : emojis[i % emojis.length];
          final angle = (-pi / 2) + (2 * pi * i / total);
          final dx = cos(angle) * orbitRadius;
          final dy = sin(angle) * orbitRadius;
          orbitChildren.add(
            Positioned(
              left: (clampedStageSize / 2) + dx - 36,
              top: (clampedStageSize / 2) + dy - 36,
              child: _EmojiBurst(emoji: emoji),
            ),
          );
        }

        return Container(
          color: Colors.transparent,
          child: Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: min(980.0, safeWidth), maxHeight: safeHeight),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: Container(
                      padding: titlePadding,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        gradient: LinearGradient(
                          colors: [
                            Colors.black.withOpacity(0.86),
                            const Color(0xFF102337).withOpacity(0.92),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(color: const Color(0xFF31C8FF).withOpacity(0.42), width: 1.8),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.38),
                            blurRadius: 24,
                            spreadRadius: 2,
                          ),
                          BoxShadow(
                            color: const Color(0xFF31C8FF).withOpacity(0.18),
                            blurRadius: 22,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            controller.overlayTitle ?? '',
                            style: TextStyle(
                              fontSize: titleFontSize,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.3,
                              shadows: const [
                                Shadow(color: Colors.black, blurRadius: 18, offset: Offset(0, 2)),
                              ],
                            ),
                            textAlign: TextAlign.center,
                          ),
                          if ((controller.overlaySubtitle ?? '').isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                controller.overlaySubtitle!,
                                style: TextStyle(
                                  fontSize: subtitleFontSize,
                                  fontWeight: FontWeight.w800,
                                  shadows: const [
                                    Shadow(color: Colors.black, blurRadius: 14, offset: Offset(0, 1)),
                                  ],
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: compact ? 10 : 16),
                  SizedBox(
                    width: clampedStageSize,
                    height: clampedStageSize,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: glowSize,
                          height: glowSize,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                const Color(0xFF31C8FF).withOpacity(0.32),
                                const Color(0xFF31C8FF).withOpacity(0.08),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                        ...orbitChildren,
                        Container(
                          width: mediaSize,
                          height: mediaSize,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(color: Colors.white.withOpacity(0.16), width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF31C8FF).withOpacity(0.35),
                                blurRadius: 34,
                                spreadRadius: 4,
                              ),
                            ],
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: media.isVideo
                              ? _VideoAssetPlayer(assetPath: media.assetPath)
                              : Image.asset(media.assetPath, fit: BoxFit.cover),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Backup Dialog
// ═══════════════════════════════════════════════════════════════
class _BackupDialog extends StatelessWidget {
  const _BackupDialog({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final backups = controller.backupList;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 500),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(colors: [Color(0xFF091522), Color(0xFF102337)]),
          border: Border.all(color: const Color(0xFFFFA726).withOpacity(0.35)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.history_rounded, size: 48, color: Color(0xFFFFA726)),
            const SizedBox(height: 10),
            const Text('Backups automáticos',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text(
              'Os 2 últimos salvamentos são mantidos automaticamente. Selecione um para restaurar.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60),
            ),
            const SizedBox(height: 18),
            if (backups.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('Nenhum backup disponível ainda.\nInteraja com o app para gerar backups.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white54)),
              )
            else
              for (var i = 0; i < backups.length; i++) ...[
                if (i > 0) const SizedBox(height: 10),
                _BackupTile(
                  entry: backups[i],
                  label: i == 0 ? 'Backup mais recente' : 'Backup anterior',
                  onRestore: () async {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Restaurar backup'),
                        content: Text('Deseja restaurar o backup ${backups[i].label}? Os dados atuais do app serão substituídos.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context, false),
                            child: const Text('Cancelar'),
                          ),
                          FilledButton(
                            onPressed: () => Navigator.pop(context, true),
                            child: const Text('Restaurar'),
                          ),
                        ],
                      ),
                    );
                    if (confirmed != true) return;
                    Navigator.pop(context);
                    await controller.restoreBackup(backups[i]);
                  },
                ),
              ],
            const SizedBox(height: 18),
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Fechar')),
          ],
        ),
      ),
    );
  }
}

class _BackupTile extends StatelessWidget {
  const _BackupTile({required this.entry, required this.label, required this.onRestore});
  final BackupEntry entry;
  final String label;
  final VoidCallback onRestore;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white.withOpacity(0.05),
        border: Border.all(color: const Color(0xFFFFA726).withOpacity(0.22)),
      ),
      child: Row(
        children: [
          const Icon(Icons.save_rounded, color: Color(0xFFFFA726)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(entry.label, style: const TextStyle(color: Colors.white60, fontSize: 13)),
            ]),
          ),
          FilledButton.icon(
            onPressed: onRestore,
            icon: const Icon(Icons.restore_rounded),
            label: const Text('Restaurar'),
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFFA726), foregroundColor: Colors.black),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Transfer Dialog
// ═══════════════════════════════════════════════════════════════
enum TransferSource { activities, extras }

class _TransferDialog extends StatefulWidget {
  const _TransferDialog({required this.schoolClass, required this.source, required this.student});
  final SchoolClass schoolClass;
  final TransferSource source;
  final StudentRecord? student;

  @override
  State<_TransferDialog> createState() => _TransferDialogState();
}

class _TransferDialogState extends State<_TransferDialog> {
  final Set<int> targets = {0};

  @override
  Widget build(BuildContext context) {
    final title = widget.source == TransferSource.activities
        ? 'Lançar médias das atividades nas AVs'
        : 'Somar pontos extras nas AVs';
    final subtitle = widget.student == null
        ? 'Selecione a(s) AV(s) para aplicar em toda a turma.'
        : 'Aplicação individual para ${widget.student!.name}.';

    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 760),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: const LinearGradient(colors: [Color(0xFF091522), Color(0xFF102337)]),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.casino_rounded, size: 52, color: Color(0xFF31C8FF)),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 18),
            Wrap(
              spacing: 12, runSpacing: 12,
              children: [
                for (final preset in [
                  ('AV1', {0}), ('AV2', {1}), ('AV3', {2}),
                  ('AV1 + AV2', {0, 1}), ('AV1 + AV3', {0, 2}), ('AV2 + AV3', {1, 2}),
                  ('AV1 + AV2 + AV3', {0, 1, 2}),
                ])
                  _TargetCard(
                    label: preset.$1,
                    selected: setEquals(targets, preset.$2),
                    onTap: () => setState(() { targets..clear()..addAll(preset.$2); }),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.black.withOpacity(0.2)),
              child: Text(
                widget.source == TransferSource.activities
                    ? 'As médias das atividades serão copiadas para as AVs escolhidas.'
                    : 'Os totais dos extras serão somados às AVs escolhidas.',
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 18),
            Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
              FilledButton.icon(
                onPressed: () => Navigator.pop(context, targets),
                icon: const Icon(Icons.check_circle_outline_rounded),
                label: const Text('Aplicar'),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Reward Dialog — só aparece ao clicar em "Adicionar ponto"
// ═══════════════════════════════════════════════════════════════
class _RewardConfig { const _RewardConfig({required this.avIndex, required this.points}); final int avIndex; final double points; }

class _RewardDialog extends StatefulWidget {
  const _RewardDialog({required this.student});
  final StudentRecord student;
  @override
  State<_RewardDialog> createState() => _RewardDialogState();
}

class _RewardDialogState extends State<_RewardDialog> {
  int avIndex = 0;
  final _pointsCtrl = TextEditingController(text: '0.5');
  @override
  void dispose() { _pointsCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Adicionar ponto • ${widget.student.name}'),
      content: SizedBox(width: 420, child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<int>(
          value: avIndex,
          items: const [
            DropdownMenuItem(value: 0, child: Text('AV1')),
            DropdownMenuItem(value: 1, child: Text('AV2')),
            DropdownMenuItem(value: 2, child: Text('AV3')),
          ],
          onChanged: (v) => setState(() => avIndex = v ?? 0),
          decoration: const InputDecoration(labelText: 'Destino'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _pointsCtrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Pontos a somar (0,5 até 10,0)'),
        ),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
        FilledButton(
          onPressed: () {
            final parsed = double.tryParse(_pointsCtrl.text.replaceAll(',', '.')) ?? 0.5;
            Navigator.pop(context, _RewardConfig(avIndex: avIndex, points: parsed.clamp(0.5, 10.0)));
          },
          child: const Text('Aplicar'),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Ranking Section — cards preenchem toda a largura
// ═══════════════════════════════════════════════════════════════
class _RankingSection extends StatelessWidget {
  const _RankingSection({required this.controller, required this.summary});
  final AppController controller;
  final ClassSummary summary;

  @override
  Widget build(BuildContext context) {
    final characters = controller.rankingCharactersFor(summary);
    const medals = ['🥇', '🥈', '🥉'];
    const crownColors = [Color(0xFFFFD54F), Color(0xFFC0C7D1), Color(0xFFCD7F32)];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(colors: [Color(0xFF0F2236), Color(0xFF152E47)]),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
        boxShadow: [BoxShadow(color: const Color(0xFF31C8FF).withOpacity(0.10), blurRadius: 28)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Ranking dos 3 melhores • Média das AVs',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('Classificação automática pela maior média das AVs.',
              style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 16),
          if (summary.ranked.isEmpty)
            const Center(child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Nenhum dado de AV para classificar.', style: TextStyle(color: Colors.white54)),
            ))
          else
            // Usa Row com Expanded para preencher toda a largura proporcionalmente
            IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  for (var i = 0; i < summary.ranked.length; i++) ...[
                    if (i > 0) const SizedBox(width: 12),
                    Expanded(
                      child: _RankCard(
                        rank: i + 1,
                        medal: medals[i],
                        crownColor: crownColors[i],
                        rankedStudent: summary.ranked[i],
                        characterAsset: characters.length > i ? characters[i] : 'assets/images/mario.png',
                      ),
                    ),
                  ],
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _RankCard extends StatelessWidget {
  const _RankCard({
    required this.rank,
    required this.medal,
    required this.crownColor,
    required this.rankedStudent,
    required this.characterAsset,
  });
  final int rank;
  final String medal;
  final Color crownColor;
  final RankedStudent rankedStudent;
  final String characterAsset;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 200),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFF15283B), Color(0xFF203E5D)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        border: Border.all(color: crownColor.withOpacity(0.45), width: 1.4),
        boxShadow: [BoxShadow(color: crownColor.withOpacity(0.18), blurRadius: 24)],
      ),
      child: Stack(
        children: [
          // Imagem do personagem
          Positioned.fill(
            child: Align(
              alignment: Alignment.centerRight,
              child: FractionallySizedBox(
                widthFactor: 0.75,
                child: Image.asset(
                  characterAsset,
                  fit: BoxFit.cover,
                  alignment: Alignment.centerRight,
                  opacity: const AlwaysStoppedAnimation(0.94),
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            ),
          ),
          // Gradiente overlay
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF06121E).withOpacity(0.95),
                    const Color(0xFF06121E).withOpacity(0.70),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 0.52, 1.0],
                  begin: Alignment.centerLeft, end: Alignment.centerRight,
                ),
              ),
            ),
          ),
          // Conteúdo de texto — determina a altura real do card
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(children: [
                  Icon(Icons.workspace_premium_rounded, color: crownColor, size: 22),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text('$medal  #$rank',
                        style: TextStyle(fontWeight: FontWeight.w900, color: crownColor, fontSize: 14),
                        overflow: TextOverflow.ellipsis),
                  ),
                ]),
                const SizedBox(height: 10),
                Text(
                  rankedStudent.student.name,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w900, height: 1.2,
                    shadows: [Shadow(color: Colors.black, blurRadius: 10)],
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12), color: Colors.black.withOpacity(0.40),
                  ),
                  child: Text(
                    'Média: ${rankedStudent.avAverage.toStringAsFixed(2)}',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(height: 6),
                Text('Nº ${rankedStudent.student.number} • ${rankedStudent.student.code}',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Text('Atividades: ${rankedStudent.activityAverage.toStringAsFixed(2)}',
                    style: const TextStyle(color: Colors.white60, fontSize: 11)),
                const SizedBox(height: 4),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


class _ClassNameEditorPage extends StatefulWidget {
  const _ClassNameEditorPage({this.initialValue});

  final String? initialValue;

  @override
  State<_ClassNameEditorPage> createState() => _ClassNameEditorPageState();
}

class _ClassNameEditorPageState extends State<_ClassNameEditorPage> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue ?? '');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _save() {
    final value = _controller.text.trim();
    if (value.isEmpty) return;
    Navigator.of(context).pop(value);
  }

  @override
  Widget build(BuildContext context) {
    final isNew = (widget.initialValue ?? '').trim().isEmpty;
    return Scaffold(
      appBar: AppBar(title: Text(isNew ? 'Nova turma' : 'Renomear turma')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _controller,
                autofocus: true,
                textInputAction: TextInputAction.done,
                decoration: const InputDecoration(
                  labelText: 'Nome da turma',
                  hintText: 'Ex.: 1º Ano A',
                ),
                onSubmitted: (_) => _save(),
              ),
              const SizedBox(height: 16),
              const Text(
                'Digite o nome da turma e toque em Salvar.',
                style: TextStyle(color: Colors.white70),
              ),
              const Spacer(),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancelar'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: _save,
                      child: const Text('Salvar'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ClassManagementPage extends StatefulWidget {
  const _ClassManagementPage({
    required this.controller,
    required this.onCreateRequested,
    required this.onRenameRequested,
    required this.onDeleteRequested,
  });

  final AppController controller;
  final Future<void> Function() onCreateRequested;
  final Future<void> Function(SchoolClass schoolClass) onRenameRequested;
  final Future<void> Function(SchoolClass schoolClass) onDeleteRequested;

  @override
  State<_ClassManagementPage> createState() => _ClassManagementPageState();
}

class _ClassManagementPageState extends State<_ClassManagementPage> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_refresh);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final classes = widget.controller.currentState.classes;
    final activeKey = widget.controller.currentState.activeClassKey;

    return Scaffold(
      appBar: AppBar(title: const Text('Gerenciar turmas')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      classes.isEmpty
                          ? 'Nenhuma turma cadastrada.'
                          : 'Toque em uma turma para ativá-la. Use os botões para renomear ou excluir.',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                  const SizedBox(width: 12),
                  FilledButton.icon(
                    onPressed: () async => widget.onCreateRequested(),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Nova turma'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: classes.isEmpty
                    ? Center(
                        child: Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(24),
                            color: Colors.white.withOpacity(0.04),
                            border: Border.all(color: Colors.white.withOpacity(0.08)),
                          ),
                          child: const Text(
                            'Crie a primeira turma ou importe um arquivo com turmas e alunos.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white70),
                          ),
                        ),
                      )
                    : ListView.separated(
                        itemCount: classes.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          final schoolClass = classes[index];
                          final isActive = schoolClass.key == activeKey;
                          return Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              color: isActive
                                  ? const Color(0xFF31C8FF).withOpacity(0.08)
                                  : Colors.white.withOpacity(0.04),
                              border: Border.all(
                                color: isActive
                                    ? const Color(0xFF31C8FF).withOpacity(0.40)
                                    : Colors.white.withOpacity(0.08),
                              ),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(14),
                                    onTap: () => widget.controller.setActiveClass(schoolClass.key),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 6),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              if (isActive)
                                                const Padding(
                                                  padding: EdgeInsets.only(right: 8),
                                                  child: Icon(Icons.check_circle_rounded, color: Color(0xFF31C8FF), size: 18),
                                                ),
                                              Expanded(
                                                child: Text(
                                                  schoolClass.title,
                                                  style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w800,
                                                    color: isActive ? const Color(0xFF31C8FF) : Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            '${schoolClass.students.length} aluno(s) • planilha: ${schoolClass.sheetName}',
                                            style: const TextStyle(color: Colors.white60, fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                IconButton(
                                  tooltip: 'Renomear turma',
                                  onPressed: () async => widget.onRenameRequested(schoolClass),
                                  icon: const Icon(Icons.edit_rounded),
                                ),
                                IconButton(
                                  tooltip: 'Excluir turma',
                                  onPressed: () async => widget.onDeleteRequested(schoolClass),
                                  icon: const Icon(Icons.delete_outline_rounded),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Widgets auxiliares
// ═══════════════════════════════════════════════════════════════
class _SmallBtn extends StatelessWidget {
  const _SmallBtn({required this.icon, required this.label, required this.onPressed, this.color});
  final IconData icon;
  final String label;
  final VoidCallback? onPressed;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return FilledButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      style: FilledButton.styleFrom(
        backgroundColor: color ?? Theme.of(context).colorScheme.primary,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        minimumSize: const Size(0, 36),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
      ),
    );
  }
}

class _TargetCard extends StatelessWidget {
  const _TargetCard({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 150,
      child: InkWell(
        onTap: onTap, borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: selected ? const LinearGradient(colors: [Color(0xFF31C8FF), Color(0xFF4AF6C3)]) : null,
            color: selected ? null : Colors.white.withOpacity(0.05),
            border: Border.all(color: selected ? Colors.transparent : Colors.white.withOpacity(0.10)),
          ),
          child: Center(child: Text(label, textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.w900, color: selected ? Colors.black : Colors.white))),
        ),
      ),
    );
  }
}

class _LegendBadge extends StatelessWidget {
  const _LegendBadge({required this.emoji, required this.text});
  final String emoji;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(999), color: Colors.white.withOpacity(0.07)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(emoji, style: const TextStyle(fontSize: 16)),
        const SizedBox(width: 6),
        Text(text, style: const TextStyle(fontSize: 12)),
      ]),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.title, required this.subtitle, required this.icon, required this.accent});
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white.withOpacity(0.05),
        border: Border.all(color: accent.withOpacity(0.22)),
      ),
      child: Row(children: [
        CircleAvatar(radius: 20, backgroundColor: accent.withOpacity(0.18), child: Icon(icon, color: accent)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 13)),
        ])),
      ]),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.subtitle, required this.actions, required this.child});
  final String title;
  final String subtitle;
  final List<Widget> actions;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(colors: [Color(0xFF0B1724), Color(0xFF0F2234)]),
        border: Border.all(color: Colors.white.withOpacity(0.09)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 13)),
        const SizedBox(height: 12),
        Wrap(spacing: 12, runSpacing: 12, children: actions),
        const SizedBox(height: 16),
        child,
      ]),
    );
  }
}

class _CountSelector extends StatelessWidget {
  const _CountSelector({required this.label, required this.value, required this.onChanged});
  final String label;
  final int value;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: Colors.white.withOpacity(0.08)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: DropdownButton<int>(
          value: value,
          underline: const SizedBox.shrink(),
          borderRadius: BorderRadius.circular(18),
          items: [for (var i = 1; i <= 10; i++) DropdownMenuItem(value: i, child: Text('$label: $i'))],
          onChanged: (v) => v == null ? null : onChanged(v),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value, required this.accent, required this.icon});
  final String title;
  final String value;
  final Color accent;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: Colors.white.withOpacity(0.05),
        border: Border.all(color: accent.withOpacity(0.18)),
      ),
      child: Row(children: [
        CircleAvatar(radius: 22, backgroundColor: accent.withOpacity(0.18), child: Icon(icon, color: accent)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13), maxLines: 2),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        ])),
      ]),
    );
  }
}

class _GenderPieCard extends StatelessWidget {
  const _GenderPieCard({required this.summary});
  final ClassSummary summary;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: Colors.white.withOpacity(0.05),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(children: [
        CustomPaint(
          size: const Size.square(78),
          painter: _PiePainter(malePct: summary.approvedMalePct, femalePct: summary.approvedFemalePct),
        ),
        const SizedBox(width: 12),
        Expanded(child: DefaultTextStyle(
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Aprovados por gênero', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('👨 ${summary.approvedMale} homens  •  ${summary.approvedMalePct.toStringAsFixed(1)}%'),
            const SizedBox(height: 4),
            Text('👩 ${summary.approvedFemale} mulheres  •  ${summary.approvedFemalePct.toStringAsFixed(1)}%'),
          ]),
        )),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Video Player
// ═══════════════════════════════════════════════════════════════
class _VideoAssetPlayer extends StatefulWidget {
  const _VideoAssetPlayer({required this.assetPath});
  final String assetPath;
  @override
  State<_VideoAssetPlayer> createState() => _VideoAssetPlayerState();
}

class _VideoAssetPlayerState extends State<_VideoAssetPlayer> {
  VideoPlayerController? _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.asset(widget.assetPath)
      ..initialize().then((_) {
        if (!mounted) return;
        _ctrl!..setLooping(true)..play();
        setState(() {});
      });
  }

  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final c = _ctrl;
    if (c == null || !c.value.isInitialized) return const Center(child: CircularProgressIndicator());
    return FittedBox(
      fit: BoxFit.cover,
      child: SizedBox(width: c.value.size.width, height: c.value.size.height, child: VideoPlayer(c)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Emoji burst animation
// ═══════════════════════════════════════════════════════════════
class _EmojiBurst extends StatefulWidget {
  const _EmojiBurst({required this.emoji});
  final String emoji;
  @override
  State<_EmojiBurst> createState() => _EmojiBurstState();
}

class _EmojiBurstState extends State<_EmojiBurst> with SingleTickerProviderStateMixin {
  late final AnimationController _ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 920))..repeat(reverse: true);
  @override
  void dispose() { _ac.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: Tween<double>(begin: 0.88, end: 1.12).animate(CurvedAnimation(parent: _ac, curve: Curves.easeInOut)),
      child: Text(widget.emoji, style: const TextStyle(fontSize: 72)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Painters
// ═══════════════════════════════════════════════════════════════
class _PiePainter extends CustomPainter {
  _PiePainter({required this.malePct, required this.femalePct});
  final double malePct;
  final double femalePct;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawArc(rect, -pi / 2, pi * 2, true, Paint()..color = Colors.white.withOpacity(0.06));
    final maleSweep = (malePct / 100) * pi * 2;
    canvas.drawArc(rect, -pi / 2, maleSweep, true, Paint()..color = const Color(0xFF31C8FF));
    canvas.drawArc(rect, -pi / 2 + maleSweep, max(0, (femalePct / 100) * pi * 2), true, Paint()..color = const Color(0xFFF06292));
    canvas.drawCircle(rect.center, size.width * 0.24, Paint()..color = const Color(0xFF0B1724));
  }

  @override
  bool shouldRepaint(covariant _PiePainter old) => old.malePct != malePct || old.femalePct != femalePct;
}

class _WheelPainter extends CustomPainter {
  _WheelPainter({required this.students, required this.selectedId});
  final List<StudentRecord> students;
  final String? selectedId;

  static const colors = [Color(0xFF0EA5E9), Color(0xFF22C55E), Color(0xFFF59E0B), Color(0xFFEF4444), Color(0xFF8B5CF6), Color(0xFF14B8A6)];

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2;
    final tp = TextPainter(textDirection: TextDirection.ltr);

    if (students.isEmpty) {
      canvas.drawCircle(center, radius, Paint()..color = Colors.white.withOpacity(0.08));
      tp.text = const TextSpan(text: 'Sem alunos', style: TextStyle(color: Colors.white70, fontSize: 22, fontWeight: FontWeight.w700));
      tp.layout();
      tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
      return;
    }

    final slice = (pi * 2) / students.length;
    for (var i = 0; i < students.length; i++) {
      final start = -pi / 2 + i * slice;
      final paint = Paint()..color = colors[i % colors.length].withOpacity(students[i].id == selectedId ? 0.95 : 0.82);
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, slice, true, paint);
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, slice, true,
          Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.black.withOpacity(0.24));

      final angle = start + slice / 2;
      final textOffset = Offset(center.dx + cos(angle) * radius * 0.72, center.dy + sin(angle) * radius * 0.72);
      tp.text = TextSpan(
        text: '${students[i].number}',
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900,
            fontSize: max(12, min(22, 360 / students.length)), shadows: const [Shadow(color: Colors.black87, blurRadius: 8)]),
      );
      tp.layout();
      canvas.save();
      canvas.translate(textOffset.dx, textOffset.dy);
      canvas.rotate(angle + pi / 2);
      tp.paint(canvas, Offset(-tp.width / 2, -tp.height / 2));
      canvas.restore();
    }
    canvas.drawCircle(center, radius - 5, Paint()..style = PaintingStyle.stroke..strokeWidth = 10..color = Colors.white.withOpacity(0.18));
  }

  @override
  bool shouldRepaint(covariant _WheelPainter old) {
    if (old.selectedId != selectedId || old.students.length != students.length) return true;
    for (var i = 0; i < students.length; i++) {
      if (old.students[i].id != students[i].id) return true;
    }
    return false;
  }
}

class _ThunderBackground extends StatelessWidget {
  const _ThunderBackground();

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.topCenter, radius: 1.4,
          colors: [Color(0xFF10253B), Color(0xFF07121C), Color(0xFF03080E)],
        ),
      ),
      child: CustomPaint(painter: _LightningPainter()),
    );
  }
}

class _LightningPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF31C8FF).withOpacity(0.12)
      ..strokeWidth = 2.5..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    final bolts = [
      [Offset(size.width * 0.08, 0), Offset(size.width * 0.14, size.height * 0.14), Offset(size.width * 0.09, size.height * 0.24), Offset(size.width * 0.18, size.height * 0.36)],
      [Offset(size.width * 0.86, 0), Offset(size.width * 0.78, size.height * 0.12), Offset(size.width * 0.82, size.height * 0.22), Offset(size.width * 0.74, size.height * 0.34)],
      [Offset(size.width * 0.46, 0), Offset(size.width * 0.52, size.height * 0.10), Offset(size.width * 0.48, size.height * 0.18)],
    ];
    for (final bolt in bolts) {
      final path = Path()..moveTo(bolt.first.dx, bolt.first.dy);
      for (final point in bolt.skip(1)) path.lineTo(point.dx, point.dy);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _TableHeader { const _TableHeader(this.label, {required this.width}); final String label; final double width; }
